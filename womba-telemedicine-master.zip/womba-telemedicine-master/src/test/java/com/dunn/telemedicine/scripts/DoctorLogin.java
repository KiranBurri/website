package com.dunn.telemedicine.scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.DoctorJoinCall;
import com.dunn.telemedicine.pages.DoctorPersonalTabUpdation;
import com.dunn.telemedicine.pages.LoginPage;
@Test

public class DoctorLogin extends Baselib
{@Test
	public void Login() throws InterruptedException
	{
	LoginPage ldoc = new LoginPage(driver);
	String username= excelLib.getData("Sheet1",5,1,Iconstants.DataexcelPath);
	String password = excelLib.getData("Sheet1",5,2,Iconstants.DataexcelPath);
	
	ldoc.doLogin(username, password);
	
	
	
	  
	}
}
