package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.DoctorScheduleAppointment;
import com.dunn.telemedicine.pages.Doctoravailibale;
import com.dunn.telemedicine.pages.GermanLanguage;
import com.dunn.telemedicine.pages.LoginPage;

public class DoctorScheduleappointment extends Baselib{
@Test
	public void joinappointment() throws InterruptedException
{

	LoginPage ldoc = new LoginPage(driver);
	String username= excelLib.getData("Sheet1",5,1,Iconstants.DataexcelPath);
	String password = excelLib.getData("Sheet1",5,2,Iconstants.DataexcelPath);
	
	ldoc.doLogin(username, password);

	    DoctorScheduleAppointment obj1=new DoctorScheduleAppointment(driver);
	    obj1.CreateAppointment();
}
}