package com.dunn.telemedicine.scripts1;

import org.openqa.selenium.By;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.listners.MyListners;
import com.dunn.telemedicine.pages.CompleteRegistrationDoctor;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.InitialPatientRegistration;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.PCompleteRegistration;

@Listeners(com.dunn.telemedicine.listners.MyListners.class)

public class PatientsRegistration extends Baselib{
	@Test
	public void Registration() throws InterruptedException
	
	{   
	InitialPatientRegistration pr = new InitialPatientRegistration(driver);
	pr.doRegistration();
		

	PCompleteRegistration cr = new PCompleteRegistration(driver);
	cr.step1();
	Thread.sleep(5000);
	cr.step2();
	cr.step3();

	
	}}
