package com.dunn.telemedicine.scripts;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class TestJoin {
	public static void main(String[] args) {
        //ChromeOptions options = new ChromeOptions();
//        options.addArguments("--disable-notifications");
//        System.setProperty("webdriver.chrome.driver", "/home/users/garima.pathak/Desktop/softwares/chromedriver");
//        WebDriver driver =new ChromeDriver(options);
//        driver.get("http://wordpressdemo.webkul.com/wordpress-latest-tweets/");
//        driver.manage().window().maximize();
        
        Map<String, Object> prefs = new HashMap<String, Object>();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("use-fake-device-for-media-stream");
        options.addArguments("use-fake-ui-for-media-stream");
        
        prefs.put("profile.default_content_setting_values.media_stream_mic", 1);
        prefs.put("profile.default_content_setting_values.media_stream_camera", 1);
        prefs.put("profile.default_content_setting_values.geolocation", 1);
        prefs.put("profile.default_content_setting_values.notifications", 1);
        options.setExperimentalOption("prefs", prefs);
     
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\git\\Telemedicine1\\WombaTelemedicine\\softwares\\chromedriver.exe");
        WebDriver  driver = new ChromeDriver(options); 
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get("https://de-telemedicine-certqa.womba.org/");
        driver.findElement(By.id("username")).sendKeys("testpatient2020@gmail.com");
        driver.findElement(By.id("password")).sendKeys("Password123@");
        driver.findElement(By.name("submit")).click();
        options.setExperimentalOption("prefs", prefs);
        driver.findElement(By.xpath("(//button[contains(text(),'Teilnehmen')])[1]")).click();

 

        
    }
}
