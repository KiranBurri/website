package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.Address;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.Insurance;
import com.dunn.telemedicine.pages.LoginPage;

public class InsuranceTab extends Baselib{
	@Test
	public void insurancetabupdate() throws InterruptedException
	{
		LoginPage lp = new LoginPage(driver);
		String un = excelLib.getData("Sheet1",2,1,Iconstants.DataexcelPath);
		String pw = excelLib.getData("Sheet1",2,2,Iconstants.DataexcelPath);
		lp.doLogin(un, pw);
		String Actualtitle = driver.getTitle();
		System.out.println("Title of Dashboard Page : " +Actualtitle);
		GermanLogout gl = new GermanLogout(driver);
		gl.changelanguage();
		Thread.sleep(5000);
		gl.changetogerman();
		Thread.sleep(5000);
		Insurance in = new Insurance(driver);
		in.profile();
		Thread.sleep(5000);
		in.insurance();
		Thread.sleep(5000);
}
}
