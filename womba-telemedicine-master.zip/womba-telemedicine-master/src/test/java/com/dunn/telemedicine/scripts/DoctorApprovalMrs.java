package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.DoctorApprovalOpenMrs;


public class DoctorApprovalMrs extends Baselib{
	@Test
	public void DoctorApprovalopenmrs() throws InterruptedException
	{
	DoctorApprovalOpenMrs obj1 = new DoctorApprovalOpenMrs(driver);
	String username= excelLib.getData("Sheet1",1,0,Iconstants.ExcelopenMrs);
	String password = excelLib.getData("Sheet1",1,1,Iconstants.ExcelopenMrs);
	String Email = excelLib.getData("Sheet1",1,2,Iconstants.ExcelopenMrs);
	obj1.DoLogin(username,password);
    obj1.Approval(Email);
}
}