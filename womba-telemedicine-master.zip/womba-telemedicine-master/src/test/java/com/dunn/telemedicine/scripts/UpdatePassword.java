package com.dunn.telemedicine.scripts;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.Insurance;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.Password;

public class UpdatePassword extends Baselib{
	@Test
	public void passwordtabupdate() throws InterruptedException, ParseException
	{//Script of Password Update 
		LoginPage lp = new LoginPage(driver);
		String un = excelLib.getData("Sheet1",2,1,Iconstants.DataexcelPath);
		String pw = excelLib.getData("Sheet1",2,2,Iconstants.DataexcelPath);
		lp.doLogin(un, pw);
		String Actualtitle = driver.getTitle();
		System.out.println("Title of Dashboard Page : " +Actualtitle);
		GermanLogout gl = new GermanLogout(driver);
		gl.changelanguage();
		Thread.sleep(5000);
		gl.changetogerman();
		Thread.sleep(5000);
		Password pd = new Password(driver);
		pd.profile();
		Thread.sleep(5000);
		pd.password();
		Thread.sleep(5000);
		
			 
		
			
}
}


