package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.Address;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.Personal;

public class AdressTab extends Baselib{
	@Test
	public void addresstabupdate() throws InterruptedException
	{
		LoginPage lp = new LoginPage(driver);
		String un = excelLib.getData("Sheet1",2,1,Iconstants.DataexcelPath);
		String pw = excelLib.getData("Sheet1",2,2,Iconstants.DataexcelPath);
		lp.doLogin(un, pw);
		String Actualtitle = driver.getTitle();
		System.out.println("Title of Dashboard Page : " +Actualtitle);
		GermanLogout gl = new GermanLogout(driver);
		gl.changelanguage();
		Thread.sleep(5000);
		gl.changetogerman();
		Thread.sleep(5000);
		Address ad = new Address(driver);
		ad.profile();
		Thread.sleep(5000);
		ad.address();
		Thread.sleep(5000);
}
}
