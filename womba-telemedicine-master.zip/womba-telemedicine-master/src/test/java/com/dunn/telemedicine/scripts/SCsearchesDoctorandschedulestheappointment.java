package com.dunn.telemedicine.scripts;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.Address;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.SCAschedulesappointment;
import com.dunn.telemedicine.pages.SCAsearchDoctorbyfieldsandselects;

public class SCsearchesDoctorandschedulestheappointment extends Baselib{
	@Test
	public void searcrdoctor() throws InterruptedException
	{
		LoginPage lp = new LoginPage(driver);
		String un = excelLib.getData("Sheet1",8,1,Iconstants.DataexcelPath);
		String pw = excelLib.getData("Sheet1",8,2,Iconstants.DataexcelPath);
		lp.doLogin(un, pw);
		String Actualtitle = driver.getTitle();
		System.out.println("Title of Dashboard Page : " +Actualtitle);
		GermanLogout gl = new GermanLogout(driver);
		gl.changelanguage();
		Thread.sleep(5000);
		gl.changetogerman();
		SCAsearchDoctorbyfieldsandselects sc = new SCAsearchDoctorbyfieldsandselects(driver);
	//	sc.SC_searchbyfname();
//		sc.SC_searchbylname();
		sc.SC_searchbyOrg();
//		sc.SC_searchbyCity();
//		sc.SC_searchbySpecilization();
		SCAschedulesappointment scapt = new SCAschedulesappointment(driver);
		scapt.newAppointment();
}
}
