package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.ScAgentVerifyPatient;

public class ScVerifyPatient extends Baselib{
	@Test
	public void Login() throws InterruptedException
	{
	LoginPage ldoc = new LoginPage(driver);
	String username= excelLib.getData("Sheet1",1,0,Iconstants.ScAgentPath);
	String password = excelLib.getData("Sheet1",1,1,Iconstants.ScAgentPath);
	
	ldoc.doLogin(username, password);
	ScAgentVerifyPatient obj=new ScAgentVerifyPatient(driver);
	obj.DoVerification("Akash");
	}

}
