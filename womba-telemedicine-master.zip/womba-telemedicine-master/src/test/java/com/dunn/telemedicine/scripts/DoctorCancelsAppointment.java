package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.CancelAppointmentDoctor;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.LoginPage;


import com.dunn.telemedicine.pages.LoginPage;

public class DoctorCancelsAppointment extends Baselib {
   
    @Test
    public void cancelAppointment() throws InterruptedException
    {
        LoginPage lp = new LoginPage(driver);
        String un = excelLib.getData("Sheet1",5,1,Iconstants.DataexcelPath);
        String pw = excelLib.getData("Sheet1",5,2,Iconstants.DataexcelPath);
        lp.doLogin(un, pw);
       
        Thread.sleep(5000);
        CancelAppointmentDoctor ca = new CancelAppointmentDoctor(driver);
        ca.cancelAppDoc();
    }
} 


