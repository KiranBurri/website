package com.dunn.telemedicine.scripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.CancelAppointmentDoctor;
import com.dunn.telemedicine.pages.DoctorAboutMe;
import com.dunn.telemedicine.pages.DoctorAddressUpdate;
import com.dunn.telemedicine.pages.DoctorAppointmentUnregisteredpat;
import com.dunn.telemedicine.pages.DoctorChangePasswordtab;
import com.dunn.telemedicine.pages.DoctorDeleteSchedul;
import com.dunn.telemedicine.pages.DoctorPersonalTabUpdation;
import com.dunn.telemedicine.pages.DoctorPracticeUpdate;
import com.dunn.telemedicine.pages.DoctorResheduleapointment;
import com.dunn.telemedicine.pages.DoctorScheduleAppointment;
import com.dunn.telemedicine.pages.Doctoravailibale;
import com.dunn.telemedicine.pages.DoctorsetSpecialDay;
import com.dunn.telemedicine.pages.GermanLanguage;
import com.dunn.telemedicine.pages.LoginPage;

public class Doctorpersonaltabudat extends Baselib{
	 @Test(alwaysRun = true ,priority=1)
	
	
	public void Doctorpersonaltabudat() throws InterruptedException
	{
	LoginPage ldoc = new LoginPage(driver);
	String username= excelLib.getData("Sheet1",5,1,Iconstants.DataexcelPath);
	String password = excelLib.getData("Sheet1",5,2,Iconstants.DataexcelPath);
	
	ldoc.doLogin(username, password);
	
	
	}
	 @Test(alwaysRun = true,priority=2)
	 public void doctortab() throws InterruptedException
	 {
	  DoctorPersonalTabUpdation ob1=new DoctorPersonalTabUpdation(driver);
	    ob1.Docpersonaltabupdate();
	    }
@Test(alwaysRun = true,priority=3)

	 public void Addresstab() throws InterruptedException
	 {
	  DoctorAddressUpdate obj2=new DoctorAddressUpdate(driver);
		
		obj2.Address();
	 }
@Test(alwaysRun = true,priority=4)
public void practicetab() throws InterruptedException
{
DoctorPracticeUpdate ob3=new DoctorPracticeUpdate(driver);

ob3.updatepractice();
}
@Test(alwaysRun = true,priority=5)
public void AboutMeTab() throws InterruptedException
{
	

DoctorAboutMe obj4=new DoctorAboutMe(driver);
obj4.doctorAboutMe();
}
@Test(alwaysRun = true,priority=6)
public void PasswordTab() throws InterruptedException
{
DoctorChangePasswordtab obj=new DoctorChangePasswordtab(driver);

obj.password();
}
@Test(alwaysRun = true,priority=7)
public void CreateSchedule() throws InterruptedException
{
Doctoravailibale obj1=new Doctoravailibale(driver);
obj1.DoAvalibility();
}
@Test(alwaysRun = true,priority=8)
public void Setspecialday() throws InterruptedException
{
	DoctorsetSpecialDay obj1=new DoctorsetSpecialDay(driver);
	obj1.setSpecial();
}

@Test(alwaysRun = true,priority=9)
public void scheduleAppointment() throws InterruptedException
{
DoctorScheduleAppointment obj1=new DoctorScheduleAppointment(driver);
obj1.CreateAppointment();
}
@Test(alwaysRun = true,priority=10)
public void reshedule() throws InterruptedException
{
DoctorResheduleapointment obj=new DoctorResheduleapointment(driver);
obj.DoctorResheduleappointment();
}
@Test(alwaysRun = true,priority=11)
public void cancelAppointment() throws InterruptedException
{
	

CancelAppointmentDoctor ca = new CancelAppointmentDoctor(driver);
ca.cancelAppDoc();
}
@Test(alwaysRun = true,priority=12)
public void UnregisteredPatientAppointment() throws InterruptedException
{
	

	DoctorAppointmentUnregisteredpat obj=new DoctorAppointmentUnregisteredpat(driver);
	obj.newAppointment();
}
@Test(alwaysRun = true,priority=13)
public void resheduleunregisteredpatient() throws InterruptedException
{
DoctorResheduleapointment obj=new DoctorResheduleapointment(driver);
obj.DoctorResheduleappointment();
}
@Test(alwaysRun = true,priority=14)
public void UnregisteredPatientcancelAppointment() throws InterruptedException
{
	

CancelAppointmentDoctor ca = new CancelAppointmentDoctor(driver);
ca.cancelAppDoc();
}
@Test(alwaysRun = true,priority=15)
public void DeleteSchedule() throws InterruptedException
{
DoctorDeleteSchedul obj1=new DoctorDeleteSchedul(driver);
obj1.DoctorDeleteSchedul();
}
@Test(alwaysRun = true,priority=16)
public void Logout() throws InterruptedException
{
	GermanLanguage obj1=new GermanLanguage(driver);
	obj1.afterlogoutinGerman();
}
}
