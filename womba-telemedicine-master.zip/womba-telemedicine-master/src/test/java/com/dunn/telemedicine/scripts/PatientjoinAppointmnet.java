package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.PatinetJoinCall;

public class PatientjoinAppointmnet extends Baselib{
	
	@Test
	public void Login() throws InterruptedException
	{
	LoginPage ldoc = new LoginPage(driver);
	String username= excelLib.getData("Sheet1",2,1,Iconstants.DataexcelPath);
	String password = excelLib.getData("Sheet1",2,2,Iconstants.DataexcelPath);
	
	ldoc.doLogin(username, password);
	PatinetJoinCall obj=new PatinetJoinCall(driver);
	
	 obj.joinCall();
	}

}
