package com.dunn.telemedicine.scripts;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.PatientScheduleApointmentDate;
import com.dunn.telemedicine.pages.PatientschedulesbyDoctorName;

public class PatientappointmentByDoctorsName extends Baselib{
	@Test
	public void patientschedulesByDoctorname() throws InterruptedException
	{
		LoginPage lp = new LoginPage(driver);
		String un = excelLib.getData("Sheet1",2,1,Iconstants.DataexcelPath);
		String pw = excelLib.getData("Sheet1",2,2,Iconstants.DataexcelPath);
		lp.doLogin(un, pw);
		String Actualtitle = driver.getTitle();
//		System.out.println("Title of Dashboard Page : " +Actualtitle);
////    	GermanLogout gl = new GermanLogout(driver);
////		gl.changelanguage();
////		Thread.sleep(5000);
////		gl.changetogerman();
////		Thread.sleep(5000);
		PatientschedulesbyDoctorName obj = new PatientschedulesbyDoctorName(driver);
		obj.schedule();
		
//		Date date = new Date(); 
//		Calendar c = Calendar.getInstance(); 
//		c.setTime(date); 
//		// Add one day to the today's date 
//		c.add(Calendar.DATE, 1); 
//		
//		 
//		String strMonth = c.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.ENGLISH); 
// 
//		String tommorowsDate = new SimpleDateFormat("MM/dd/yyyy").format(c.getTime()); 
//		System.out.println(tommorowsDate);
		
}
}
