package com.dunn.telemedicine.scripts1;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.Address;
import com.dunn.telemedicine.pages.CancelAppointmentDoctor;
import com.dunn.telemedicine.pages.CancelAppointmentPatient;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.Insurance;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.Password;
import com.dunn.telemedicine.pages.PatientScheduleApointmentDate;
import com.dunn.telemedicine.pages.PatientschedulesbyDoctorName;
import com.dunn.telemedicine.pages.Personal;
import com.dunn.telemedicine.pages.ViewsAppointments;

public class PatientModule extends Baselib{
	@Test(alwaysRun = true,priority=1)
	
	public void patientmodule() throws InterruptedException
	{
	//Patient Login
	LoginPage lp = new LoginPage(driver);
	String un = excelLib.getData("Sheet1",2,1,Iconstants.DataexcelPath);
	String pw = excelLib.getData("Sheet1",2,2,Iconstants.DataexcelPath);
	lp.doLogin(un, pw);
	}
	

	
	//Patient Profile Updation
	
	@Test(alwaysRun = true,priority=2)
	public void personaltab() throws InterruptedException {
	//Personal Tab
	Personal pl = new Personal(driver);
	pl.profile();
	Thread.sleep(5000);
	pl.personal();
	Thread.sleep(5000);
	}

	@Test(alwaysRun = true,priority=3)
	public void addresstab() throws InterruptedException {	
	//Address Tab
	JavascriptExecutor js = (JavascriptExecutor) driver;
    js.executeScript("window.scrollBy(0,-200)");
	Address ad = new Address(driver);
	ad.address();
	Thread.sleep(5000);
	}

//	@Test(alwaysRun = true,priority=4)
//	public void insurancetab1() throws InterruptedException {
////	//Insurance Tab
//	JavascriptExecutor js = (JavascriptExecutor) driver;
//	js.executeScript("window.scrollBy(0,-200)");
//	Thread.sleep(5000);
//	Insurance in = new Insurance(driver);
//	in.insurance();
//	Thread.sleep(5000);
//	}
	
	@Test(alwaysRun = true,priority=5)
	public void passwdtab() throws InterruptedException {
	//Password Tab
	JavascriptExecutor js = (JavascriptExecutor) driver;
    js.executeScript("window.scrollBy(0,-200)");
	Password pd = new Password(driver);
	pd.password();
	Thread.sleep(5000);
	}
	
	@Test(alwaysRun = true,priority=6)
	public void pschedulesapptbydate() throws InterruptedException {
	//Patient schedules appointment by date 
	PatientScheduleApointmentDate obj1 = new PatientScheduleApointmentDate(driver);
	obj1.schedule();
	}
	
	@Test(alwaysRun = true,priority=7)
	public void pschedulesapptbyname() throws InterruptedException {
	//Patient Schedules appointment by name 
	PatientschedulesbyDoctorName obj = new PatientschedulesbyDoctorName(driver);
	obj.schedule();
	}
	
	@Test(alwaysRun = true,priority=8)
	public void Viewsappointment() {
	//Patient Views Appointment
	ViewsAppointments va = new ViewsAppointments(driver);
	va.appointments();
	}
	
	@Test(alwaysRun = true,priority=9)
	public void cancelappt() throws InterruptedException {
	//Patient Cancels the appointment
	CancelAppointmentPatient ca = new CancelAppointmentPatient(driver);
	ca.cancelApp();
	}
	
	
}


