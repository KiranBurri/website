package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.DoctorAboutMe;
import com.dunn.telemedicine.pages.DoctorAddressUpdate;
import com.dunn.telemedicine.pages.GermanLanguage;
import com.dunn.telemedicine.pages.LoginPage;

public class DoctorAbout extends Baselib {
	@Test
	public void About() throws InterruptedException
	{
	LoginPage ldoc = new LoginPage(driver);
	String username= excelLib.getData("Sheet1",5,1,Iconstants.DataexcelPath);
	String password = excelLib.getData("Sheet1",5,2,Iconstants.DataexcelPath);
	
	ldoc.doLogin(username, password);
	
	    DoctorAboutMe obj=new DoctorAboutMe(driver);
	    obj.doctorAboutMe();
		DoctorAddressUpdate obj1=new DoctorAddressUpdate(driver);
		
		obj1.Address();
}
}