package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.CompleteRegistrationDoctor;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.PCompleteRegistration;

public class PatientCompleteRegistration extends Baselib{
	@Test
	public void personaltabupdate() throws InterruptedException
	{
	LoginPage lp = new LoginPage(driver);
	String un = excelLib.getData("Sheet1",10,1,Iconstants.DataexcelPath);
	String pw = excelLib.getData("Sheet1",10,2,Iconstants.DataexcelPath);
	lp.doLogin(un, pw);

	PCompleteRegistration cr = new PCompleteRegistration(driver);
//	cr.step1();
//	Thread.sleep(5000);
//	cr.step2();
	Thread.sleep(5000);
	cr.step3();
}
}
