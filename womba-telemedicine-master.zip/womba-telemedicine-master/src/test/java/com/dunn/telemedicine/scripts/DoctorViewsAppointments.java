package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.DoctorAppointments;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.ViewsAppointments;

public class DoctorViewsAppointments extends Baselib {
	
	@Test
	public void viewsAppointment() throws InterruptedException
	{
	LoginPage lp = new LoginPage(driver);
	String un = excelLib.getData("Sheet1",3,1,Iconstants.DataexcelPath);
	String pw = excelLib.getData("Sheet1",3,2,Iconstants.DataexcelPath);
	lp.doLogin(un, pw);
	GermanLogout gl = new GermanLogout(driver);
	gl.changelanguage();
	Thread.sleep(5000);
	gl.changetogerman();
	Thread.sleep(5000);
	DoctorAppointments da = new DoctorAppointments(driver);
	da.doctorappointments();
	}
}
