package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.DoctorAppointmentUnregisteredpat;
import com.dunn.telemedicine.pages.LoginPage;

public class DoctorUnregisteredpatappointment extends Baselib{
	@Test
	public void UnregisteredApp() throws InterruptedException
{

	LoginPage ldoc = new LoginPage(driver);
	String username= excelLib.getData("Sheet1",5,1,Iconstants.DataexcelPath);
	String password = excelLib.getData("Sheet1",5,2,Iconstants.DataexcelPath);
	
	ldoc.doLogin(username, password);
	DoctorAppointmentUnregisteredpat obj=new DoctorAppointmentUnregisteredpat(driver);
	obj.newAppointment();
}
}