package com.dunn.telemedicine.scripts;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.CompleteRegistrationDoctor;
import com.dunn.telemedicine.pages.GermanLanguage;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.RegistrationPage;

public class DoctorCompleteRegistration extends Baselib {
	@Test
	public void DoctorCompleteRegister() throws InterruptedException
	{ 
		LoginPage ldoc = new LoginPage(driver);
		String username= excelLib.getData("Sheet1",5,1,Iconstants.DataexcelPath);
		String password = excelLib.getData("Sheet1",5,2,Iconstants.DataexcelPath);
		
		ldoc.doLogin(username, password);
		
		String titleExpected= "Schritt 1 von 3"; 
		
	    Thread.sleep(10000);
		String Titleextrated=driver.findElement(By.xpath("//div[@class=\"profile-step-info\"]")).getText();
		Assert.assertEquals( Titleextrated,titleExpected);
		String Address1 = excelLib.getData("Sheet1",2,5,Iconstants.RegistrationPath);
		
		String City = excelLib.getData("Sheet1",2,7,Iconstants.RegistrationPath);
		
		CompleteRegistrationDoctor obj=new CompleteRegistrationDoctor(driver);
		obj.DoCompleteRegistration(Address1, City);
		
		
		
		
	}

}
