package com.dunn.telemedicine.scripts;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.SCAreschedules;
import com.dunn.telemedicine.pages.SCAschedulesappointment;
import com.dunn.telemedicine.pages.SCAsearchDoctorbyfieldsandselects;
@Listeners(com.dunn.telemedicine.listners.MyListners.class)

public class SCArescheduleAppointment extends Baselib{
	@Test
	public void rescheduleappointmentBySCAgent() throws InterruptedException
	{
		LoginPage lp = new LoginPage(driver);
		String un = excelLib.getData("Sheet1",8,1,Iconstants.DataexcelPath);
		String pw = excelLib.getData("Sheet1",8,2,Iconstants.DataexcelPath);
		lp.doLogin(un, pw);
		String Actualtitle = driver.getTitle();
		System.out.println("Title of Dashboard Page : " +Actualtitle);
		SCAsearchDoctorbyfieldsandselects sc = new SCAsearchDoctorbyfieldsandselects(driver);
			sc.SC_searchbyfname();
//			sc.SC_searchbylname();
//			sc.SC_searchbyOrg();
//			sc.SC_searchbyCity();
//			sc.SC_searchbySpecilization();
//			SCAschedulesappointment scapt = new SCAschedulesappointment(driver);
//			scapt.newAppointment();
			Thread.sleep(5000);
		SCAreschedules scar = new SCAreschedules(driver);
		scar.SCAResheduleappointment();
		
		
}
}