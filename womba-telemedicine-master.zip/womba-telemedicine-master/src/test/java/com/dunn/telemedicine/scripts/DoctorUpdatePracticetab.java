package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.DoctorPracticeUpdate;
import com.dunn.telemedicine.pages.LoginPage;

public class DoctorUpdatePracticetab extends Baselib{

	@Test
	public void practicfdvdetab() throws InterruptedException
	{

		LoginPage ldoc = new LoginPage(driver);
		String username= excelLib.getData("Sheet1",5,1,Iconstants.DataexcelPath);
		String password = excelLib.getData("Sheet1",5,2,Iconstants.DataexcelPath);
		
		ldoc.doLogin(username, password);
		DoctorPracticeUpdate obj=new DoctorPracticeUpdate(driver);
		obj.profile();
		obj.updatepractice();

	}
}
