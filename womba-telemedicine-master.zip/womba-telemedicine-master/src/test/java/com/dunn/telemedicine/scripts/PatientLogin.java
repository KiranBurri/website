package com.dunn.telemedicine.scripts;

public class PatientLogin {

}
