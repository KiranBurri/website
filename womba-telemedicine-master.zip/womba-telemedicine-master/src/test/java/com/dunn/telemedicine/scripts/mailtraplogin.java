package com.dunn.telemedicine.scripts;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.mailtrapinbox;

public class mailtraplogin extends Baselib{
@Test
public void login() throws InterruptedException
{
mailtrapinbox obj=new mailtrapinbox(driver);
String un = excelLib.getData("Sheet1",1,0,Iconstants.DataexcelPath1);
String pw = excelLib.getData("Sheet1",1,1,Iconstants.DataexcelPath1);
String Doctoremail = excelLib.getData("Sheet1",1,2,Iconstants.DataexcelPath1);

obj.Verifydoctor(un,pw,Doctoremail);

}

}