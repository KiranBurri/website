package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.InitialPatientRegistration;

public class PatientsInitialRegistration extends Baselib{
	@Test
	public void Registration() throws InterruptedException
	
	{   
	InitialPatientRegistration pr = new InitialPatientRegistration(driver);
	pr.doRegistration();
	
	}}
