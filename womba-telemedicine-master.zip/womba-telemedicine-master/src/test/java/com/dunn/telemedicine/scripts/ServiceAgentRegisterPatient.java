package com.dunn.telemedicine.scripts;

import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.Personal;
import com.dunn.telemedicine.pages.SCAgentRegisterPatient;

public class ServiceAgentRegisterPatient extends Baselib{
	@Test
	public void ScRegisterPatients() throws InterruptedException
	{
		LoginPage lp = new LoginPage(driver);
		String un = excelLib.getData("Sheet1",8,1,Iconstants.DataexcelPath);
		String pw = excelLib.getData("Sheet1",8,2,Iconstants.DataexcelPath);
		lp.doLogin(un, pw);
		String Actualtitle = driver.getTitle();
		System.out.println("Title of Dashboard Page : " +Actualtitle);
		SCAgentRegisterPatient rp = new SCAgentRegisterPatient(driver);
		rp.register();

}
}