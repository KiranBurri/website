package com.dunn.telemedicine.scripts1;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.GermanLogout;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.SCAgentRegisterPatient;
import com.dunn.telemedicine.pages.SCAreschedules;
import com.dunn.telemedicine.pages.SCAschedulesappointment;
import com.dunn.telemedicine.pages.SCAsearchDoctorbyfieldsandselects;
@Listeners(com.dunn.telemedicine.listners.MyListners.class)

public class SCAgentModule extends Baselib{
	@Test(alwaysRun = true,priority=1)
	public void Login() throws InterruptedException
	{
		LoginPage lp = new LoginPage(driver);
		String un = excelLib.getData("Sheet1",8,1,Iconstants.DataexcelPath);
		String pw = excelLib.getData("Sheet1",8,2,Iconstants.DataexcelPath);
		lp.doLogin(un, pw);
	}
		
		@Test(alwaysRun = true, priority=2)
		public void scregister() throws InterruptedException
		{
		//SCA registers patient
		SCAgentRegisterPatient rp = new SCAgentRegisterPatient(driver);
		rp.register();
		}
		
		@Test(alwaysRun = true,priority=3)
		public void scsearch() throws InterruptedException
		{
		//SCA searches the doctors with different fields
		SCAsearchDoctorbyfieldsandselects sc = new SCAsearchDoctorbyfieldsandselects(driver);
			sc.SC_searchbyfname();
//			sc.SC_searchbylname();
//			sc.SC_searchbyOrg();
//			sc.SC_searchbyCity();
//			sc.SC_searchbySpecilization();
		}
		
		@Test(alwaysRun = true,priority=4)
		public void scschedules() throws InterruptedException
		{
			
		//SCA schedules appointment
		SCAschedulesappointment scapt = new SCAschedulesappointment(driver);
		scapt.newAppointment();
		}
		
		@Test(alwaysRun = true,priority=5)
		public void screschedules() throws InterruptedException
		{
		//SCA Reschedules the appointment
		SCAreschedules scar = new SCAreschedules(driver);
		scar.SCAResheduleappointment();
		}
		}

