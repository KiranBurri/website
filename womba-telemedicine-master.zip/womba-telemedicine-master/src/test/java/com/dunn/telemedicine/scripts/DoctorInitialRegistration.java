package com.dunn.telemedicine.scripts;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.Baselib;
import com.dunn.telemedicine.lib.excelLib;
import com.dunn.telemedicine.pages.CompleteRegistrationDoctor;
import com.dunn.telemedicine.pages.GermanLanguage;
import com.dunn.telemedicine.pages.LoginPage;
import com.dunn.telemedicine.pages.RegistrationPage;
import com.dunn.telemedicine.pages.mailtrapinbox;

public class DoctorInitialRegistration extends Baselib{
	@Test
	public void Registration() throws InterruptedException
	
	{ 
		
		RegistrationPage DR= new RegistrationPage(driver);
		String Firstname = excelLib.getData("Sheet1",1,0,Iconstants.RegistrationPath);
		String Lastname = excelLib.getData("Sheet1",1,1,Iconstants.RegistrationPath);
		String Email = excelLib.getData("Sheet1",1,2,Iconstants.RegistrationPath);
		String password1 = excelLib.getData("Sheet1",1,3,Iconstants.RegistrationPath);
		String password2 = excelLib.getData("Sheet1",1,4,Iconstants.RegistrationPath);
		
		  
       
		DR.doRegistration(Firstname, Lastname,Email,password1,password2);
		mailtrapinbox obj=new mailtrapinbox(driver);
		String un = excelLib.getData("Sheet1",1,0,Iconstants.DataexcelPath1);
		String pw = excelLib.getData("Sheet1",1,1,Iconstants.DataexcelPath1);
		String Doctoremail = excelLib.getData("Sheet1",1,2,Iconstants.DataexcelPath1);

		obj.Verifydoctor(un,pw,Doctoremail);
		/**/
		
		LoginPage ldoc = new LoginPage(driver);
		String username= excelLib.getData("Sheet1",5,1,Iconstants.DataexcelPath);
		String password = excelLib.getData("Sheet1",5,2,Iconstants.DataexcelPath);
		
		ldoc.doLogin(username, password);
		
		String titleExpected= "Schritt 1 von 3"; 
		
	    Thread.sleep(10000);
		String Titleextrated=driver.findElement(By.xpath("//div[@class=\"profile-step-info\"]")).getText();
		Assert.assertEquals( Titleextrated,titleExpected);
		String Address1 = excelLib.getData("Sheet1",2,5,Iconstants.RegistrationPath);
		
		String City = excelLib.getData("Sheet1",2,7,Iconstants.RegistrationPath);
		
		CompleteRegistrationDoctor obj1=new CompleteRegistrationDoctor(driver);
		obj1.DoCompleteRegistration(Address1, City);
	
		}
	


}
