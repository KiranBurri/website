package com.dunn.telemedicine.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.dunn.telemedicine.lib.GenericLib;

public class SCAgentRegisterPatient {
WebDriver driver;
	
	@FindBy(xpath = "(//a[@routerlinkactive='active'])[1]")
	private WebElement MouseOver;
	
	@FindBy(xpath = "//i[@class='fa fa-edit']")
	private WebElement RegisterPatient;
	
	@FindBy(name = "firstName")
	private WebElement Fname;
	
	@FindBy(name = "lastName")
	private WebElement lName;
	
	@FindBy(name = "gender")
	private WebElement Gender;
	
	@FindBy(name = "email")
	private WebElement Mail;
	
	@FindBy(xpath = "//input[@placeholder='TT/MM/JJJJ' and @name='dob' ]")
	private WebElement DOB;
	
	@FindBy(name = "address1")
	private WebElement Address1;
	
	@FindBy(name = "city")
	private WebElement CITY;
	
	@FindBy(name = "zip")
	private WebElement ZIP;
	
	@FindBy(name= "mobilePhoneCountryCode")
	private WebElement mobilePhoneCode;
	
	@FindBy(name= "mobilePhone")
	private WebElement mobilePhoneNumber;
	
	@FindBy(xpath = "//span[contains(text(),'Patient hinzuf�gen')]")
	private WebElement Register;
	
	@FindBy(xpath = "//div[@role='alertdialog']")
	private WebElement alertmessage;
	
	
	
	public SCAgentRegisterPatient(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	
	public void register() throws InterruptedException {
		Actions ac = new Actions(driver);
		ac.moveToElement(MouseOver);
		Thread.sleep(5000);
		GenericLib.clickElement(driver, RegisterPatient, "Register Patient Button");
		GenericLib.enterText(driver, Fname, "Test", "Fname Box");
		GenericLib.enterText(driver, lName, "Duck50", "Last Name Box");
		Select sc = new Select(Gender);
		sc.selectByValue("F");
		int randomPIN = (int)(Math.random()*9000)+1000;
		String Email="patientautomation"+randomPIN+"@gmail.com";
		System.out.print(Email);
		
		GenericLib.enterText(driver, Mail, Email, "Mail Box");
		DOB.click();
		Thread.sleep(5000);
		GenericLib.enterText(driver, DOB, "01/01/1996", "DOB field ");		
		GenericLib.clickElement(driver, Fname,  "Fname Box");
		GenericLib.enterText(driver, Address1, "20th street", "Address1 Box");
		GenericLib.enterText(driver, CITY, "Bangalore", "City Box");
		GenericLib.enterText(driver, ZIP, "570024", "ZIP Box");
		Select sl = new Select(mobilePhoneCode);
		sl.selectByVisibleText("Indien (+91)");
		GenericLib.enterText(driver,mobilePhoneNumber , "8792734161", "Mobile Phone Number Button");
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(5000);
		GenericLib.clickElement(driver, Register, "Register Button");
		Thread.sleep(5000);
		System.out.println("Message after Registration : "+alertmessage.getText());
		}

}
