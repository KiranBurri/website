package com.dunn.telemedicine.pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.dunn.telemedicine.lib.GenericLib;

public class DoctorResheduleapointment {
WebDriver driver;
@FindBy(id = "firstName")
private WebElement fname ;

@FindBy(xpath="//*[text()=\"Vorname\"]")
private WebElement vorname;
//*[@class="change-date-calendar field-structure"]
@FindBy(xpath = "//*[@class=\"fa fa-angle-right\"]")
private WebElement changedate ;
    @FindBy(xpath = "//span[@class='ladda-label']")
    private WebElement select ;
    
    @FindBy(xpath = "//*[contains(@class, 'fa fa-gear fa-lg')]")
    private WebElement Reshedulebtn;
    
    @FindBy(xpath = "//*[text()=\"Neuterminierung\"]")
    private WebElement Reshedulebtndropdown;
    
    
    @FindBy(xpath = "(//input[@class='datetime-picker' and @name=''])[2]")
    private WebElement AptDate;

    @FindBy(xpath = "//td[@class=\"xdsoft_date xdsoft_day_of_week5 xdsoft_date\"]")
    private WebElement date; 

    @FindBy(xpath = "(//*[contains(@class, 'btn btn-time')])[2]")
    private WebElement time;
    
    @FindBy(xpath = "//button[@class=\"btn btn-blue action-button full\" and @type=\"button\"]")
    private WebElement ScheduleAppointment;
    
    @FindBy(xpath = "//button[contains(text(),' CONFIRM ')]")
    private WebElement ConfirmAppointment;
    
    @FindBy(xpath = "//button[contains(text(),'Best�tigen')]")
    private WebElement GermanConfirmAppointment;
	
	public DoctorResheduleapointment(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
        
        
	}
  

	public void DoctorResheduleappointment() throws InterruptedException {
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
        Calendar cal = Calendar.getInstance();
       
	     
	      Thread.sleep(7000);
	      GenericLib.clickElement(driver,changedate , "DOB Text Box");
	      Thread.sleep(5000);
	        GenericLib.handleAction(driver, Reshedulebtn, "Reshedule Button");
	        Thread.sleep(2000);
	        GenericLib.handleAction(driver, Reshedulebtndropdown, "Reshedule Button");
	        Thread.sleep(2000);
	        AptDate.clear();
	        Thread.sleep(4000);
	        AptDate.clear();
	        Thread.sleep(5000);
	        

	        cal.add(Calendar.DAY_OF_MONTH, 2);
	        String newDate = formatter.format(cal.getTime());
	      
	        Thread.sleep(3000);
	        GenericLib.enterText(driver, AptDate,newDate , "DOB Text Box");
	        Thread.sleep(3000);
	        GenericLib.clickElement(driver, vorname, "voranmr click");
	        Thread.sleep(3000);
	        
	        
	        GenericLib.handleAction(driver,time, "time button");
	        
	        Thread.sleep(6000);
	        
	        
	        GenericLib.clickElement(driver, ScheduleAppointment, "ScheduleAppointment Button");
	        try {
	            GenericLib.handleAction(driver, GermanConfirmAppointment, "Confirm Appointment Button");
	        } catch (Exception e) {
	            GenericLib.handleAction(driver, ConfirmAppointment, "Confirm Appointment Button");        }
	        
		   
		
		   
	}

}
