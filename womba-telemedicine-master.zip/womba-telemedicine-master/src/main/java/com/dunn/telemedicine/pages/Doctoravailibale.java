package com.dunn.telemedicine.pages;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class Doctoravailibale {
	
	WebDriver driver;
	@FindBy(xpath = "//a[@href=\"#/doctor/availability\"]")
    private WebElement Availibiltybtn;
	
	@FindBy(xpath = "//button[@class=\"close pull-right\"]")
    private WebElement Closebtn;
	
	@FindBy(xpath = "//button[text()=\"Neuer Kalender\"]")
    private WebElement NewSchedule;
	
	
	@FindBy(name = "name")
    private WebElement NewScheduleName;
	
	@FindBy(name = "newStartingDate")
    private WebElement Startdate;
	
	
	@FindBy(name = "newEndingDate")
    private WebElement EndDate;
	
	@FindBy(xpath = "//button[@class=\"btn btn-success btn-blue action-button full\"]")
    private WebElement AddScheduleBtn;
	
	@FindBy(xpath = "//a[@href=\"#/doctor\"]")
    private WebElement DoctorhomeBtn;
	
	@FindBy(xpath = "//button[text()=\" Speichern \"]")
    private WebElement Savebtn;
	
	
	
	public Doctoravailibale(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
public void	DoAvalibility() throws InterruptedException
{JavascriptExecutor js = (JavascriptExecutor) driver;

	Thread.sleep(5000);
	GenericLib.clickElement(driver, DoctorhomeBtn ,"doctorhomebutton");
	Thread.sleep(3000);
	GenericLib.clickElement(driver, Availibiltybtn ,"Availibilitybutton");
	Thread.sleep(3000);
	try {
	GenericLib.clickElement(driver, Closebtn ,"closebutton");
	}
	catch(Exception e)
	{
	
		
	}
	finally
	{	Thread.sleep(2000);
	GenericLib.clickElement(driver, NewSchedule ,"Newshedulebutton");
	driver.findElement(By.name("name")).sendKeys("test1");
	Thread.sleep(2000);
	GenericLib.clickElement(driver, Startdate ,"Newshedulebutton");
	Thread.sleep(3000);
	SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
    Date date = new Date();
    System.out.println(formatter.format(date));
    String startdate=formatter.format(date);
    Calendar cal = Calendar.getInstance();

    cal.add(Calendar.DAY_OF_MONTH, 3);
    String EndDate = formatter.format(cal.getTime());
    
    System.out.println(formatter.format(date));
    System.out.println(EndDate);

    Thread.sleep(5000);
	   driver.findElement(By.xpath("(//input[@name=\"newStartingDate\"])[1]")).sendKeys(startdate);
	   Thread.sleep(3000);
	   driver.findElement(By.name("name")).click();
	   Thread.sleep(2000);
	   driver.findElement(By.xpath("(//input[@name=\"newEndingDate\"])[1]")).sendKeys("*");
	   
	   Thread.sleep(4000);
	  driver.findElement(By.xpath("(//input[@name=\"newEndingDate\"])[1]")).sendKeys(EndDate);
	  driver.findElement(By.name("name")).click();
	Thread.sleep(2000);
	
	driver.findElement(By.name("name")).click();
		Thread.sleep(3000);

	   GenericLib.clickElement(driver, AddScheduleBtn ,"Add schedule button");
	   Thread.sleep(12000);
	   js.executeScript("window.scrollBy(0,300)");
	   for(int i=1;i<=7;i++)
	   {
		
		   driver.findElement(By.xpath("((//div[@id=\"scheduleContainer\"])[1]//*[text()=\"01:30\"][1])["+i+"]")).click();
	   
	   }
	   Thread.sleep(3000);
	   GenericLib.clickElement(driver,Savebtn  ,"Save shedule");
	   
	
	}
	Thread.sleep(5000);
driver.findElement(By.xpath("//*[text()=\" Kalender ist erfolgreich gespeichert worden. \"]"));
   
     
     
	
}
	
}
