package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class mailtrapinbox {
	
	
	WebDriver driver;
	
	

	@FindBy(xpath ="//a[text()=\"Log in\"]")
	private WebElement Login;

	@FindBy(id ="user_email")
	private WebElement useremail;
	
	@FindBy(id ="user_password")
	private WebElement userpassword;
	
	@FindBy(name ="commit")
	private WebElement loginbutton;
	
	@FindBy(xpath ="(//*[@class=\"inbox_name\"])[3]")
	private WebElement STdLink;
	
	@FindBy(xpath ="//*[text()='testhedh@gmail.com']")
	private WebElement DoctorEmail;
	
	@FindBy(xpath ="//*[text()=\"Benutzerkonto best�tigen\"]")
	private WebElement VerifyLink;
	
	
	
	
	
	
	
	public mailtrapinbox(WebDriver driver) {
	 
	 
	//Maximize the browser  
	 driver.manage().window().maximize(); 
        this.driver=driver;
        PageFactory.initElements(driver, this);
        
        
	}
	public void Verifydoctor(String username, String Password, String Doctoremail) throws InterruptedException
    {	
    
     
driver.navigate().to("https://mailtrap.io/"); 
		GenericLib.clickElement(driver,Login, "Login button click");
		 GenericLib.enterText(driver, useremail,username , "username entered");
		 GenericLib.enterText(driver,userpassword ,Password , "Password entered");
		 GenericLib.clickElement(driver,loginbutton, "Login button click");
		GenericLib.clickElement(driver,STdLink, "Inbox email click");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[text()='"+Doctoremail+"']")).click();
		driver.switchTo().frame(0);
	Thread.sleep(6000);
	GenericLib.clickElement(driver,VerifyLink, "Doctor email click");
	
	// String ExpectedText="Ihr Profil wurde aktualisiert.";
/*	 WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Ihre Anmeldung')]")));
     String ActualText=     driver.findElement(By.xpath("//*[contains(text(),'Ihre Anmeldung')]")).getText();
          System.out.println(ActualText);*/
          
     //     Assert.assertEquals(ExpectedText, ActualText);
    }
}
