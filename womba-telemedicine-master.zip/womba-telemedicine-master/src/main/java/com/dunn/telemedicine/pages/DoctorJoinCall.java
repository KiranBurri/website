package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dunn.telemedicine.lib.GenericLib;

public class DoctorJoinCall {
	WebDriver driver;
	
	@FindBy(xpath = "(//*[text()=' Teilnehmen '])[1]")
    private WebElement appointmentbtn;
	
	  @FindBy(xpath = "//*[@class=\"fa fa-angle-right\"]")
	    private WebElement changedate ;
	  @FindBy(xpath = "//a[@href=\"#/doctor\"]")
	    private WebElement DoctorhomeBtn;

    public DoctorJoinCall(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
        }
public void joinCall() throws InterruptedException
{  
	Thread.sleep(5000);
	GenericLib.clickElement(driver, DoctorhomeBtn ,"doctorhomebutton");
	Thread.sleep(3000);
      GenericLib.clickElement(driver,changedate , "DOB Text Box");
      Thread.sleep(3000);
WebDriverWait wait = new WebDriverWait(driver,30);
wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[text()=' Teilnehmen '])[1]")));
GenericLib.clickElement(driver, appointmentbtn, "voranmr click");
}
}
