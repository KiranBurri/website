package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class PatientschedulesbyDoctorName {
	WebDriver driver;
	int i;
	int i1;
	
	@FindBy(xpath = "//a[@class='k-link']")
	private WebElement scheduleappointment;
	
	@FindBy(xpath = "//main[@id='content']/schedule-visit/div[2]/aw-wizard/div/aw-wizard-step[1]/reason-for-visit/div/div[1]/p")
	private WebElement ReasonforVisit;
	
	@FindBy(xpath = "//select[@class='ng-untouched ng-pristine ng-valid']")
	private WebElement duration;
	
	@FindBy(xpath = "(//button[@class='btn btn-blue float-right'])[1]")
	private WebElement saveContinue;
	
	@FindBy(xpath = "//*[@id='content']/schedule-visit/div[2]/aw-wizard/div/aw-wizard-step[3]/doctor-search/div[1]/div[2]/p")
	private WebElement SearchAppointmentDate;
	
	@FindBy(xpath = "//input[@id='lastNameFilter']")
	private WebElement lastname ;
	
	@FindBy(xpath = "//button[@type='submit']")
	private WebElement Search;
	
	@FindBy(xpath = "(//button[contains(text(),'Terminplanung')])[1]")
	private WebElement selectdoctor;
	
	@FindBy(xpath = "//input[@class='datetime-picker' and @name='appointmentDate']")
	private WebElement appointmentdate;
	
	@FindBy(xpath = "(//button[@type='button'])[6]")
	private WebElement ScheduleApt2;
	
	@FindBy(xpath = "//*[@id=\"content\"]/schedule-visit/div[2]/aw-wizard/div/aw-wizard-step[5]/appointment-time/div[1]/div[3]/datetime-picker/input")
	private WebElement Starttime2;
	
	@FindBy(xpath = "(//button[@type='button' and @class='btn btn-blue float-right'])[3]")
	private WebElement skip;

	@FindBy(xpath = "//div[@role='alertdialog']")
	private WebElement alertmessage;
	
	@FindBy(xpath = "//div[@class='navbar-logo']")
	private WebElement Wombalogo;
	
	public PatientschedulesbyDoctorName(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void schedule () throws InterruptedException {
		
		System.out.println("*****************************");
		System.out.println("*------ Patient Schedules the Appointment By NAME ------*");
		GenericLib.handleAction(driver, Wombalogo, "Womba Logo");
		
		String text2 = driver.findElement(By.xpath("//*[@class='paging-info']")).getText();
        
        System.out.println("Before scheduling the appointment , Details of Appointment : "+text2);
        String segments3[] = text2.split("f");
        
         String document3 = segments3[segments3.length - 1];
         System.out.println(document3);
         int iend1 = document3.indexOf("E"); 

         String subString1;
         if (iend1 != -1) 
         	{
        	 subString1= document3.substring(1 , iend1-1);
        	 System.out.println(subString1);
        	 i=Integer.parseInt(subString1);  
         	}
         
		GenericLib.handleAction(driver, scheduleappointment, "scheduleappointment appointment");
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,200)");
		GenericLib.clickElement(driver, ReasonforVisit, "ReasonforVisit Button");
		GenericLib.clickElement(driver, duration, "Duration Button");
		Select st = new Select(duration);
		st.selectByIndex(1);
		Thread.sleep(5000);
		GenericLib.handleAction(driver, saveContinue, "Save and Continue Button");
		Thread.sleep(5000);
        js.executeScript("window.scrollBy(0,200)");
		GenericLib.clickElement(driver, SearchAppointmentDate, "SearchAppointmentDate");
		Thread.sleep(2000);
		GenericLib.enterText(driver, lastname, "ronald11", "Last field Text Box");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, Search, "Search Button");
		Thread.sleep(5000);
		js.executeScript("window.scrollBy(0,300)");
		GenericLib.clickElement(driver, selectdoctor, "Select Doctor Button");
		Thread.sleep(2000);
		GenericLib.clickElement(driver, appointmentdate, "Appointment date text box");
		Thread.sleep(5000);
		GenericLib.enterText(driver, appointmentdate,"*" , "DOB Text Box");
		GenericLib.enterText(driver, appointmentdate,"date" , "DOB Text Box");
		Thread.sleep(6000);
		GenericLib.handleAction(driver, ScheduleApt2, "ScheduleApt Button");
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,1000)");
		GenericLib.handleAction(driver, skip, "skip Button");
		Thread.sleep(7000);
		String ExpectedText="Ihr Termin wurde zu Ihrem Zeitplan hinzugef�gt.";
	    String ActualText = driver.findElement(By.xpath("//div[@role='alertdialog']")).getText();
	    System.out.println("Schedule appointment by doctor's name message : "+alertmessage.getText());
	    Thread.sleep(3000);
	    Assert.assertEquals(ActualText,ExpectedText);
	    
	    Thread.sleep(5000);
		 String text1=    driver.findElement(By.xpath("//*[@class=\"paging-info\"]")).getText();
       
       System.out.println("After scheduling the appointment , Details of Appointment : "+text1);
       String segments[] = text1.split("f");
   
       String document = segments[segments.length - 1];
     //  System.out.println(document);
       int iend = document.indexOf("E"); 

       String subString;
       if (iend != -1) 
       {
       	subString= document.substring(1 , iend-1);
       //	System.out.println(subString);
       	i1=Integer.parseInt(subString); 
       	if(i1<i)
       	{
       		System.out.println("Script success");   
       		}
       	else
       	{
       		System.out.println("Script failed");   
       	}
       }
       System.out.println("----------------------------------------");
	    }
}