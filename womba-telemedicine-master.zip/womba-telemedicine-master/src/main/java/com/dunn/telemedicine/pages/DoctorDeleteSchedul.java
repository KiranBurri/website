package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class DoctorDeleteSchedul {
	WebDriver driver;
	@FindBy(xpath = "//a[@href=\"#/doctor/availability\"]")
    private WebElement Availibiltybtn;
	
	@FindBy(xpath = "//button[@class=\"close pull-right\"]")
    private WebElement Closebtn;
	
	@FindBy(xpath = "//*[@class=\"btn btn-danger pull-right\"]")
    private WebElement Deleteshedule;
	@FindBy(xpath = "//a[@href=\"#/doctor\"]")
    private WebElement DoctorhomeBtn;
	

    public DoctorDeleteSchedul(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void	DoctorDeleteSchedul() throws InterruptedException
	{    Thread.sleep(5000);
	GenericLib.clickElement(driver, DoctorhomeBtn ,"doctorhomebutton");
    Thread.sleep(5000);
		GenericLib.clickElement(driver, Availibiltybtn ,"Availibilitybutton");
		Thread.sleep(3000);
		
		
		
		Select CallingCode= new Select(driver.findElement(By.xpath("//select[@class=\"ng-untouched ng-pristine ng-valid\"]")));
		CallingCode.selectByVisibleText("test1");
		Thread.sleep(5000);
		GenericLib.clickElement(driver, Deleteshedule ,"Deleteshedue");
		Thread.sleep(2000);
		
	//	String textexpected="�Kalender ist erfolgreich entfernt worden.";
		 	driver.findElement(By.xpath("//*[contains(text(),'Kalender ist erfolgreich entfernt worden.')]"));
	//	    Assert.assertEquals(textActual, textexpected);
		 	try {
		 		GenericLib.clickElement(driver, Closebtn ,"closebutton");
		 		}
		 		catch(Exception e)
		 		{
		 		
		 			
		 		}

	}
	
}
