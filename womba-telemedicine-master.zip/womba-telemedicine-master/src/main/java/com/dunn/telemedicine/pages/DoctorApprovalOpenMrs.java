package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class DoctorApprovalOpenMrs {
	WebDriver driver;
	
    
    @FindBy(id = "username")
    private WebElement username ;
    
    @FindBy(id ="password")
    private WebElement password ;
    
    @FindBy(xpath = "//input[@type='submit']")
    private WebElement login ;
    
    @FindBy(xpath = "//a[@href=\"/admin/index.htm\"]")
    private WebElement Administration; 
    
    @FindBy(xpath = "(//*[@class=\"adminMenuList\"])[26]/ul//*[text()=\"Arztgenehmigung\"]")
    private WebElement DoctorApproval;
    
    @FindBy(name ="verify")
    private WebElement  Checkbox;
    
    @FindBy(id ="saveButton")
    private WebElement saveButton ;
    
    
    public DoctorApprovalOpenMrs (WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }
        public void DoLogin(String Username,String Password) {
        	driver.navigate().to("https://de-telemedicine-certqa-admin.dunnsolutions.com/admin/users/users.list");
        	
        	GenericLib.enterText(driver, username, Username, "Username TextBox");
        	GenericLib.enterText(driver, password, Password, "password TextBox");
        	GenericLib.clickElement(driver, login, "Login Btn");
        	
        	
        }
        
        public void  Approval(String 	Email) throws InterruptedException
        {  
        	JavascriptExecutor js = (JavascriptExecutor) driver;
        	GenericLib.handleAction(driver, Administration, "DropDown Button");
        	Thread.sleep(10000);
        	js.executeScript("window.scrollBy(0,1000)");
        	Thread.sleep(8000);
        	GenericLib.handleAction(driver, DoctorApproval, "approval link");
        	Thread.sleep(20000);
        
        	  WebElement Element = driver.findElement(By.xpath("//*[text()='"+Email+"']/preceding::a[1]"));

              //This will scroll the page till the element is found		
              js.executeScript("arguments[0].scrollIntoView();", Element);
        	driver.findElement(By.xpath("//*[text()='"+Email+"']/preceding::a[1]")).click();
        	Thread.sleep(5000);
        	js.executeScript("arguments[0].scrollIntoView();", saveButton);
        	GenericLib.handleAction(driver, Checkbox, "checkbox");
        	GenericLib.clickElement(driver, saveButton, "Login Btn");
        	  String ExpectedText="Arztgenehmigung";
              String ActualText= driver.findElement(By.xpath("//*[text()=\"Arztgenehmigung\"]")).getText();
              
              Assert.assertEquals(ActualText,ExpectedText);
        	
        }
	}
 
  

