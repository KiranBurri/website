package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.GenericLib;
import com.dunn.telemedicine.lib.excelLib;

public class ViewsAppointments {
	WebDriver driver;
	
	
	@FindBy(xpath = "//a[@class='k-link k-state-active']")
	private WebElement aptment;
	
	@FindBy(xpath = "//h1[contains(text(),' N�chste Termine')]")
	private WebElement upcomingappointments;
	
	@FindBy(xpath = "//div[@class='navbar-logo']")
	private WebElement Wombalogo;
	
	public ViewsAppointments(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void appointments() {
		GenericLib.handleAction(driver, Wombalogo, "Womba Logo");
		GenericLib.clickElement(driver, aptment, "Appointment Button");
		System.out.println(aptment.getText());
		System.out.println(upcomingappointments.getText());
		String ac = driver.findElement(By.xpath("//h1[contains(text(),' N�chste Termine')]")).getText();	
		String expec = "N�chste Termine";
		Assert.assertEquals(ac, expec);
	}

}
