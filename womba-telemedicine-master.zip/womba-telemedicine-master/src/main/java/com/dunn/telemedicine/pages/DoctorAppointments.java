package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class DoctorAppointments {
WebDriver driver;
	
	
	@FindBy(xpath = "(//a[@class='k-link'])[1]")
	private WebElement aptment;
	
	public DoctorAppointments(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void doctorappointments() {
		GenericLib.clickElement(driver, aptment, "Appointment Button");
		String ExpectedText=" Termine ";
	    String ActualText = driver.findElement(By.xpath("//*[@id=\"content\"]/doctor-home-page/tokbox/div[1]/div[1]/h1/text()")).getText();
	    Assert.assertEquals(ActualText,ExpectedText);
	}
}
