package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class Password {
WebDriver driver;
	
	@FindBy(id = "navbarDropdownMenuLink")
	private WebElement Dropdown;
	
	@FindBy(xpath = "//a[@id='profile']")
	private WebElement Profile;
	
	@FindBy(xpath = "(//li/a[@class='nav-link'])[3]")
	private WebElement Password;
	
	@FindBy(name = "currentPassword")
	private WebElement CurrentPassword;
	
	@FindBy(name = "password1")
	private WebElement newPassword;
	
	@FindBy(name = "password2")
	private WebElement confirmPassword;
	
	@FindBy(xpath  = "//button[@type='submit']")
	private WebElement updatePassword;
	
	@FindBy(xpath = "//div[@role='alertdialog']")
	private WebElement alertmessage;
	
	
	public Password(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		}

	public void profile() throws InterruptedException {
		GenericLib.handleAction(driver, Dropdown, "DropDown Button");
		Thread.sleep(2000);
		GenericLib.handleAction(driver, Profile, "Profile Button");
		}
	
	public void password() throws InterruptedException {
		GenericLib.handleAction(driver, Password, "Password Button");
		Thread.sleep(2000);
		GenericLib.enterText(driver, CurrentPassword, "Password123@", "CurrentPassword Box");
		Thread.sleep(2000);
		GenericLib.enterText(driver, newPassword, "Password123@", "NewPassword Box");
		Thread.sleep(2000);
		GenericLib.enterText(driver, confirmPassword, "Password123@", "ConfirmPassword Box");
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,40)");
		GenericLib.clickElement(driver, updatePassword, "updatePassword Button");
		Thread.sleep(5000);
//		System.out.println(alertmessage.getText());
//		String ExpectedText="das Passwort wurde ge�ndert.";     
//        String textActual= driver.findElement(By.xpath("//div[@role='alertdialog']")).getText();
//        Assert.assertEquals(textActual,ExpectedText);
        //---------------
        WebDriverWait wait = new WebDriverWait(driver,20);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='alertdialog']")));
        String ExpectedText1="das Passwort wurde ge�ndert.";
        String ActualText=driver.findElement(By.xpath("//div[@role='alertdialog']")).getText();
        System.out.println(alertmessage.getText());
        Assert.assertEquals(ActualText,ExpectedText1);
	}

}
