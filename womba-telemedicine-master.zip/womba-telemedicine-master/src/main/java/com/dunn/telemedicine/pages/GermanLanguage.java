package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.dunn.telemedicine.lib.GenericLib;

public class GermanLanguage {
	WebDriver driver;
    @FindBy(id = "languageDropdown")
    private WebElement ChangeLanguage;
    
    @FindBy(xpath = "//a[contains(text(),'Deutschland (Deutsch)')]")
    private WebElement Changegerman;
    
    @FindBy(id = "navbarDropdownMenuLink")
    private WebElement Dropdown;
    
    @FindBy(id ="logout")
    private WebElement germanLogout;
    
    public GermanLanguage(WebDriver driver) {
          this.driver=driver;
          PageFactory.initElements(driver, this);
    }

    public void changelanguage() {
          GenericLib.clickElement(driver, ChangeLanguage, "ChangeLanguage Button");
    }

    public void changetogerman() throws InterruptedException {
          GenericLib.handleAction(driver, Changegerman, "German Language Button");
          Thread.sleep(5000);
      //    WebElement appointments = driver.findElement(By.xpath("//a[@class='k-link k-state-active']"));
       //   System.out.println(appointments.getText());
      //    String actual = appointments.getText();
          //String expected = excelLib.getData("Sheet1",3,4,Iconstants.Expectedoutput);
          //Assert.assertEquals(actual, expected);
          
    }
    
    public void afterlogoutinGerman() throws InterruptedException {
          GenericLib.handleAction(driver, Dropdown, "DropDown Button");
          GenericLib.handleAction(driver, germanLogout, "Logout Button");
       
          driver.findElement(By.xpath("//*[contains(text(),'Anmelden')]"));
    }

	

}
