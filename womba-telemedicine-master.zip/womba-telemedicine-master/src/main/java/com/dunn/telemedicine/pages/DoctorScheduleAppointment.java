package com.dunn.telemedicine.pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.dunn.telemedicine.lib.GenericLib;

public class DoctorScheduleAppointment {
	WebDriver driver;
	int i;
	int i1;
	
	
    
    @FindBy(xpath = "//span[@class='ladda-label']")
    private WebElement select ;
    
    @FindBy(xpath = "(//button[@type='button'])[1]")
    private WebElement newAptButton ;
    
    @FindBy(id = "firstName")
    private WebElement fname ;
    
    @FindBy(id = "lastName")
    private WebElement lname ;
    
    @FindBy(id = "email")
    private WebElement Email ;
    
    @FindBy(xpath = "//input[@class='datetime-picker' and @name='dob']")
    private WebElement Dob;
    
    @FindBy(xpath = "//input[@class='datetime-picker' and @name='appointmentDate']")
    private WebElement AptDate;

 

    @FindBy(xpath = "(//*[contains(@class, 'btn btn-time')])[1]")
    private WebElement time;
    
    @FindBy(xpath = "//button[@type='submit']")
    private WebElement ScheduleAppointment;
    
    @FindBy(xpath = "//button[contains(text(),' CONFIRM ')]")
    private WebElement ConfirmAppointment;
    
    @FindBy(xpath = "//button[contains(text(),'Best�tigen')]")
    private WebElement GermanConfirmAppointment;
    
	@FindBy(xpath = "//a[@href=\"#/doctor\"]")
    private WebElement DoctorhomeBtn;
	
	public DoctorScheduleAppointment(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
        
        
	}
  

	public void CreateAppointment() throws InterruptedException {
		
		Thread.sleep(5000);
		GenericLib.clickElement(driver, DoctorhomeBtn ,"doctorhomebutton");
	      Thread.sleep(5000);
	      
	      String text2=    driver.findElement(By.xpath("//*[@class=\"paging-info\"]")).getText();
    	   
	     	System.out.println(text2);
	     	String segments3[] = text2.split("f");
	     // Grab the last segment
	     	
	     String document3 = segments3[segments3.length - 1];
	     System.out.println(document3);
	     int iend1 = document3.indexOf("E"); //this finds the first occurrence of "." 
	   //in string thus giving you the index of where it is in the string

	   // Now iend can be -1, if lets say the string had no "." at all in it i.e. no "." is found. 
	   //So check and account for it.

	   String subString1;
	   if (iend1 != -1) 
	   {
	       subString1= document3.substring(1 , iend1-1);
	       System.out.println(subString1);
	        i=Integer.parseInt(subString1);  
	       //this will give abc
	   }
	        GenericLib.handleAction(driver, newAptButton, "New Apt Button Button");
	        Thread.sleep(2000);
	        GenericLib.enterText(driver, fname, "Henry", "fname Box");
	        Thread.sleep(2000);
	        GenericLib.enterText(driver, lname, "mark", "lname Box");
	        Thread.sleep(2000);
	        GenericLib.enterText(driver, Email, "testpatient2020@gmail.com", "Email Box");
	        Dob.clear();
	        Thread.sleep(2000);
	        GenericLib.enterText(driver, Dob, "*", "DOB Text Box");
	        Thread.sleep(3000);
	      
	        GenericLib.enterText(driver, Dob, "01.02.1991", "DOB Text Box");
	        GenericLib.clickElement(driver, Dob, "Dob field");
	        Thread.sleep(1000);
	        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
	        Calendar cal = Calendar.getInstance();

	        cal.add(Calendar.DAY_OF_MONTH, 1);
	        String newDate = formatter.format(cal.getTime());
	        Thread.sleep(3000);
	        AptDate.clear();
	        Thread.sleep(3000);
	        AptDate.clear();
	       GenericLib.enterText(driver, AptDate,"*" , "DOB Text Box");
	      //  GenericLib.enterText(driver, AptDate,"00" , "DOB Text Box");
	       // Thread.sleep(9000);
	        GenericLib.enterText(driver, AptDate,newDate , "DOB Text Box");
	        
	        Thread.sleep(3000);
	        GenericLib.clickElement(driver, fname, "");
	        Thread.sleep(7000);
	        GenericLib.clickElement(driver, time, "time button");
	        GenericLib.clickElement(driver, ScheduleAppointment, "ScheduleAppointment Button");
	        try {
	            GenericLib.handleAction(driver, GermanConfirmAppointment, "Confirm Appointment Button");
	            Thread.sleep(10000);
	            String text1=    driver.findElement(By.xpath("//*[@class=\"paging-info\"]")).getText();
	     	   
	     	System.out.println(text1);
	     	String segments[] = text1.split("f");
	     // Grab the last segment
	     	
	     String document = segments[segments.length - 1];
	     System.out.println(document);
	     int iend = document.indexOf("E"); //this finds the first occurrence of "." 
	   //in string thus giving you the index of where it is in the string

	   // Now iend can be -1, if lets say the string had no "." at all in it i.e. no "." is found. 
	   //So check and account for it.

	   String subString;
	   if (iend != -1) 
	   {
	       subString= document.substring(1 , iend-1);
	       System.out.println(subString);
	        i1=Integer.parseInt(subString); 
	       if(i1>i)
	       {
	    	System.out.println("Script success");   
	       }
	       else
	       {
	    	   System.out.println("Script failed");   
	       }
	       
	   }
	   
	     
	        } catch (Exception e) {
	          
	        	GenericLib.handleAction(driver, ConfirmAppointment, "Confirm Appointment Button");        }

		   
		   
	}
	

}
