package com.dunn.telemedicine.pages;

import java.awt.Window;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class InitialPatientRegistration {
WebDriver driver;

@FindBy(xpath = "(//a[@class='k-link'])[2]")
private WebElement CreateAccbtn;

@FindBy(xpath = "//a[contains(text(),'Patient')]")
private WebElement PatientTab;

@FindBy(name = "firstName")
private WebElement FirstName;

@FindBy(name = "lastName")
private WebElement LastName;

@FindBy(name = "gender")
private WebElement Gender;

@FindBy(name = "email")
private WebElement Email;

@FindBy(name = "password1")
private WebElement Password;

@FindBy(name = "password2")
private WebElement ConfirmPassword;

@FindBy(xpath = "(//span[@class='fake-label-inline'])[1]")
private WebElement TermsCondition;

@FindBy(xpath = "(//span[@class='fake-label-inline'])[2]")
private WebElement Declaration;

@FindBy(xpath = "(//span[@class='tenant-button-text'])[1]")
private WebElement CreateAccount;

@FindBy(xpath="//div[@class='alert alert-success']")
private WebElement alertm;



public InitialPatientRegistration(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
}
public void doRegistration() throws InterruptedException
{
	GenericLib.clickElement(driver, CreateAccbtn ,"createaccountbutton");
	
	GenericLib.clickElement(driver,  PatientTab ,"Patientaccountbutton");
	GenericLib.enterText(driver, FirstName, "Patient", "firstname TextBox");
	GenericLib.enterText(driver, LastName, "Automation 03", "lastname TextBox");
	GenericLib.clickElement(driver, Gender  ,"gender");
	Select Gender = new Select(driver.findElement(By.name("gender")));
	Gender.selectByIndex(1);
	GenericLib.enterText(driver, Email, "patientautomation53@gmail.com", "email TextBox");
	GenericLib.enterText(driver, Password, "Password123@", "password1 TextBox");
	GenericLib.enterText(driver, ConfirmPassword, "Password123@", "passwor2 TextBox");
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,2000)");
	Thread.sleep(10000);
	GenericLib.handleAction(driver, TermsCondition, "Terms and Condition Check Box");
	Thread.sleep(5000);
	js.executeScript("window.scrollBy(0,40)");
	GenericLib.handleAction(driver, Declaration, "Declaration Check Box");
	Thread.sleep(5000);
	String Actual= CreateAccbtn.getText();
	String Expected = "Konto erstellen";
	Assert.assertEquals(Actual, Expected);
	GenericLib.clickElement(driver, CreateAccount, "Create Account Button");
	try {
		Thread.sleep(5000);
		WebElement Alertmsg = driver.findElement(By.xpath("//div[@role='alertdialog']"));
		System.out.println("Message After Initial Registration : " +Alertmsg.getText());
			} 
	catch (Exception e) {
		System.out.println("Message After Initial Registration : "+alertm.getText());
		}
	

}

}
