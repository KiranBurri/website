package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class DoctorsetSpecialDay {
	WebDriver driver;
	@FindBy(xpath = "//a[@href=\"#/doctor/special-days\"]")
    private WebElement Specialdaybtn;
	
	@FindBy(xpath = "(//div[contains(@class, 'calendar-month')])[9]//ul[@class=\"days\"]/li[20]")
    private WebElement Choosespecialday;
	
	@FindBy(xpath = "//button[contains(@class, 'btn-toggle')]")
    private WebElement Makedayoffbtn;
	@FindBy(xpath = "//*[text()=\"Speichern\"]")
    private WebElement MakedayoffSave;
	
	@FindBy(xpath = "//a[@href=\"#/doctor\"]")
    private WebElement DoctorhomeBtn;
	@FindBy(xpath = "//*[@type=\"button\" and @aria-label=\"Close\"]")
    private WebElement closebtn;
	
	
    public DoctorsetSpecialDay(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	
	}
	public void setSpecial() throws InterruptedException {
		
		Thread.sleep(5000);
		GenericLib.clickElement(driver, DoctorhomeBtn ,"doctorhomebutton");
	      Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		GenericLib.clickElement(driver, Specialdaybtn ,"Setspecialday");
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,1000)");
		
		GenericLib.clickElement(driver, Choosespecialday ,"Selectsepecial day");
		js.executeScript("window.scrollBy(0,-1000)");
		GenericLib.clickElement(driver, Makedayoffbtn ,"Makedayoffbtn");
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(3000);
		GenericLib.clickElement(driver,  MakedayoffSave,"MakedayoffSave");
		
		String ExpectedText="erfogreich gespeichert";
		                                                  
        String 	textActual=	driver.findElement(By.xpath("//*[contains(@class, 'alert alert-success')]")).getText();
		Assert.assertEquals(textActual,ExpectedText);
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(5000);
		GenericLib.clickElement(driver,  closebtn,"Close btn");
		
		
		
	}
}
