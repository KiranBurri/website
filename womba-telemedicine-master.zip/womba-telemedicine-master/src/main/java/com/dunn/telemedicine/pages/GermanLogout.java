package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.GenericLib;
import com.dunn.telemedicine.lib.excelLib;

public class GermanLogout {
	WebDriver driver;
	@FindBy(id = "languageDropdown")
	private WebElement ChangeLanguage;
	
	@FindBy(xpath = "//a[contains(text(),'Deutschland (Deutsch)')]")
	private WebElement Changegerman;
	
	@FindBy(xpath = "//a[contains(text(),'United States (English)')]")
	private WebElement ChangeEnglish;
	
	@FindBy(id = "navbarDropdownMenuLink")
	private WebElement Dropdown;
	
	@FindBy(id ="logout")
	private WebElement germanLogout;
	
	public GermanLogout(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void changelanguage() {
		GenericLib.clickElement(driver, ChangeLanguage, "ChangeLanguage Button");
	}
   
	public void changetogerman() throws InterruptedException {
		GenericLib.handleAction(driver, Changegerman, "German Language Button");
		Thread.sleep(5000);
		}
	
	public void changetoEnglish() throws InterruptedException {
		GenericLib.handleAction(driver, ChangeEnglish, "English Language Button");
		Thread.sleep(5000);
		}
	
	public void afterlogoutinGerman() throws InterruptedException {
		GenericLib.handleAction(driver, Dropdown, "DropDown Button");
		GenericLib.handleAction(driver, germanLogout, "Logout Button");
		Thread.sleep(5000);
		String ac = driver.findElement(By.xpath("(//a[@class='k-link'])[1]")).getText();
		String expec = "Anmelden";
		Assert.assertEquals(ac, expec);

	}

}
