package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class Address {
WebDriver driver;
	
	@FindBy(id = "navbarDropdownMenuLink")
	private WebElement Dropdown;
	
	@FindBy(xpath = "//a[@id='profile']")
	private WebElement Profile;
	
	@FindBy(xpath = "(//li/a[@class='nav-link'])[1]")
	private WebElement Address;
	
	@FindBy(name = "address1")
	private WebElement Address1;
	
	@FindBy(name = "zip")
	private WebElement ZIP;
	
	@FindBy(name = "city")
	private WebElement CITY;
	
	@FindBy(name = "mobilePhoneCountryCode")
	private WebElement MbCountryCode;
	
	@FindBy(name = "mobilePhone")
	private WebElement MBNumber;
	
	@FindBy(xpath  = "//button[contains(text(),'Speichern')]")
	private WebElement save;
	
	@FindBy(xpath = "//div[@role='alertdialog']")
	private WebElement alertmessage;
	
	public Address(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void profile() {
		GenericLib.handleAction(driver, Dropdown, "DropDown Button");
		GenericLib.handleAction(driver, Profile, "Profile Button");
		}
	
	public void address() throws InterruptedException {
		
		GenericLib.handleAction(driver, Address, "Address Button");
		Thread.sleep(2000);
		Address1.clear();
		Thread.sleep(2000);
		GenericLib.enterText(driver, Address1, "4th Street , 3rd Cross ", "Address1 box");
		Thread.sleep(2000);
		ZIP.clear();
		Thread.sleep(5000);
		GenericLib.enterText(driver, ZIP, "570024", "ZIP box");
		Thread.sleep(2000);
		CITY.clear();
		Thread.sleep(2000);
		GenericLib.enterText(driver, CITY, "MYSORE", "CITY box");
		Thread.sleep(2000);
		GenericLib.handleAction(driver, MbCountryCode, "MbCountryCode box");
		Thread.sleep(2000);
		MBNumber.clear();
		Thread.sleep(2000);
		GenericLib.enterText(driver, MBNumber, "8792734161", "MBNumber box");
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,200)");
		GenericLib.clickElement(driver, save, "Save Button");
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver,20);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='alertdialog']")));
        String ExpectedText="Ihr Profil wurde aktualisiert.";
        String ActualText=driver.findElement(By.xpath("//div[@role='alertdialog']")).getText();
        System.out.println(alertmessage.getText());
        Assert.assertEquals(ActualText,ExpectedText);
	}
}
