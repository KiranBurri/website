package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class DoctorAboutMe {

	WebDriver driver;
	@FindBy(id = "navbarDropdownMenuLink")
	private WebElement Dropdown;

	@FindBy(xpath = "//a[@id='profile']")
	private WebElement Profile;
	@FindBy(name = "bio")
    private WebElement BioText;
	
	@FindBy(name = "website")
    private WebElement websiteText;
	
	@FindBy(name = "school")
    private WebElement SchoolText;
	
	
	@FindBy(name = "degree")
    private WebElement degreeText;
	
	@FindBy(name = "address")
    private WebElement addressText;
	
	
	@FindBy(name = "country")
    private WebElement CountryText;
	@FindBy(xpath = "//*[@class=\"nav-link\" and @href=\"#/doctor/profile/about-me\"]")
    private WebElement Practicebtn;
	@FindBy(xpath = "//*[@class=\"btn btn-blue save\"]")
    private WebElement SaveBtn;
	
	@FindBy(xpath = "//div[@role='alertdialog']")
    private WebElement alertmessage;
	
	public DoctorAboutMe(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void doctorAboutMe() throws InterruptedException
	{String biotext1="Bio of Doctor";
	 String Website="https://doctbio.com";
	 String school="Rotary";
	 String dgree="Rotary";
	 String address="Jayanagar";
	 String Country="India";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		Thread.sleep(5000);
		
		 
		js.executeScript("window.scrollBy(0,-400)");
	 GenericLib.clickElement(driver,Dropdown, "profiledropdown");
	 GenericLib.clickElement(driver,Profile, "profileSelect");
	 GenericLib.clickElement(driver,Practicebtn, "practicebtn");
	 Thread.sleep(4000);
	 BioText.clear();
		GenericLib.enterText(driver, BioText, biotext1, "Username TextBox");
		websiteText.clear();
		GenericLib.enterText(driver, websiteText,Website , "password TextBox");
		SchoolText.clear();
		GenericLib.enterText(driver, SchoolText, school, "password TextBox");
		degreeText.clear();
		GenericLib.enterText(driver, degreeText, dgree, "password TextBox");
		addressText.clear();
		GenericLib.enterText(driver, addressText,address , "password TextBox");
		CountryText.clear();
		GenericLib.enterText(driver, CountryText,Country , "password TextBox");
		
		js.executeScript("window.scrollBy(0,200)");
		GenericLib.clickElement(driver,SaveBtn, "savebtn");
		WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='alertdialog']")));
        String ExpectedText="Ihr Profil wurde aktualisiert.";
        
        String ActualText=     driver.findElement(By.xpath("//div[@role='alertdialog']")).getText();
             System.out.println(alertmessage.getText());
             Assert.assertEquals(ActualText,ExpectedText);
	}

}
