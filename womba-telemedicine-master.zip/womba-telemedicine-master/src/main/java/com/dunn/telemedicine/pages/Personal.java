package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class Personal {
	WebDriver driver;
	
	@FindBy(id = "navbarDropdownMenuLink")
	private WebElement Dropdown;
	
	@FindBy(xpath = "//a[@id='profile']")
	private WebElement Profile;
	
	@FindBy(xpath = "(//li[@class='nav-item'])[1]")
	private WebElement Personal;
	
	@FindBy(name = "firstName")
	private WebElement fName;
	
	@FindBy(name = "lastName")
	private WebElement lName;
	
	@FindBy(name = "dob")
	private WebElement DOB;
	
	@FindBy(name = "sex")
	private WebElement Gender;
	
	@FindBy(name = "timezone")
	private WebElement Timezone;
	
	@FindBy(xpath = "//button[@type='submit']")
	private WebElement save;
	
	@FindBy(xpath = "//div[@role='alertdialog']")
	private WebElement alertmessage;
	
	public Personal(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void profile() throws InterruptedException {
		GenericLib.handleAction(driver, Dropdown, "DropDown Button");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, Profile, "Profile Button");
		}
	
	public void personal() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		GenericLib.handleAction(driver, Personal, "Personal Button");
		Thread.sleep(2000);
		fName.clear();
		Thread.sleep(2000);
		GenericLib.enterText(driver, fName, "Test3", "fName box");
		Thread.sleep(2000);
		lName.clear();
		Thread.sleep(2000);
		GenericLib.enterText(driver, lName, "patient3", "lName box");
		Thread.sleep(2000);
		Gender.click();
		Select sl = new Select(Gender);
		sl.selectByVisibleText("m�nnlich");
		Thread.sleep(2000);
		Select sc = new Select(Timezone);
		sc.selectByValue("Europe/Berlin");
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,200)");
		GenericLib.handleAction(driver, save, "Save Button");
		Thread.sleep(2000);
		System.out.println(alertmessage.getText());
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver,20);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='alertdialog']")));
        String ExpectedText="Ihr Profil wurde aktualisiert.";
        String ActualText=driver.findElement(By.xpath("//div[@role='alertdialog']")).getText();
        System.out.println(alertmessage.getText());
        Assert.assertEquals(ActualText,ExpectedText);
	}
}
