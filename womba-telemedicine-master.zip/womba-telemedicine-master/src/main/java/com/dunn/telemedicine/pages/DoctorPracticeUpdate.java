package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class DoctorPracticeUpdate {
	WebDriver driver;
	 @FindBy(id = "navbarDropdownMenuLink")
	    private WebElement Dropdown;
	    
	    @FindBy(xpath = "//a[@id='profile']")
	    private WebElement Profile;
	    
	    @FindBy(xpath = "(//li[@class=\"nav-item ng-star-inserted\"])[2]")
	    private WebElement practice;
	    
	    @FindBy(xpath = "//button[@class=\"btn btn-blue save pull-right\"]")
	    private WebElement Savebtn ;
	    
@FindBy(name="physicianCertificationNumber")
private WebElement Certificate;

@FindBy(name="bsnrNumber")
private WebElement Bsnr;

@FindBy(xpath = "//button[@class=\"btn btn-smallAdd\"]")
private WebElement Addspecializationbtn;
@FindBy(xpath = "//button[@class=\"id-card-upload-button btn btn-blue\"]")
private WebElement addPhysicianId;

@FindBy(xpath = "//*[@type=\"submit\"]")
private WebElement submit3;

@FindBy(xpath = "//div[@role='alertdialog']")
private WebElement alertmessage;

public DoctorPracticeUpdate(WebDriver driver) {
    this.driver=driver;
    PageFactory.initElements(driver, this);
    }



public void profile() throws InterruptedException {
    GenericLib.handleAction(driver, Dropdown, "DropDown Button");
    Thread.sleep(2000);
    GenericLib.handleAction(driver, Profile, "Profile Button");
    }
public void updatepractice() throws InterruptedException


{
	Thread.sleep(5000);
	
	JavascriptExecutor js = (JavascriptExecutor) driver;  
	js.executeScript("window.scrollBy(0,-400)");
	GenericLib.handleAction(driver, practice, "Password Button");
    Thread.sleep(3000);
	Certificate.clear();
GenericLib.enterText(driver,Certificate, "1234567890", "Certificate no");
Thread.sleep(3000);
	Bsnr.clear();
	GenericLib.enterText(driver,Bsnr, "888888888", "bsnr no");
	GenericLib.clickElement(driver,Addspecializationbtn, "Add specialization");
	Select Specialization= new Select(driver.findElement(By.xpath("//select[@class=\"form-control multipleSelect ng-untouched ng-pristine ng-invalid\"]")));
	Specialization.selectByIndex(1);
	Thread.sleep(2000);

    Thread.sleep(5000);
   
    driver.findElement(By.xpath("(//input[@type='file'])[2]")).sendKeys("C:\\Users\\Admin\\Downloads\\Simpson_Homer(2) (1).pdf");
    Thread.sleep(5000);

	
	
	js.executeScript("window.scrollBy(0,600)");
	GenericLib.clickElement(driver,Savebtn, "Savebtn");
	  String ExpectedText="Ihr Profil wurde aktualisiert.";
	  WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='alertdialog']")));
      String ActualText=     driver.findElement(By.xpath("//div[@role='alertdialog']")).getText();
           System.out.println(alertmessage.getText());
           Assert.assertEquals(ActualText,ExpectedText);
	
}
}
