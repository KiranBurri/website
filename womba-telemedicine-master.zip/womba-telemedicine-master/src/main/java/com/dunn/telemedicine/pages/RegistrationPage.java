package com.dunn.telemedicine.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.dunn.telemedicine.init.Iconstants;
import com.dunn.telemedicine.lib.GenericLib;
import com.dunn.telemedicine.lib.excelLib;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class RegistrationPage {
	WebDriver driver;
	@FindBy(xpath = "(//a[@class=\"k-link\"])[2]")
	private WebElement CreateAccbtn;

	@FindBy(xpath = "(//a[@class=\"switch\"])[1]")
	private WebElement doctorbtn;

	@FindBy(name = "firstName")
	private WebElement FirstName;
	
	@FindBy(name = "lastName")
	private WebElement LastName;
	
	@FindBy(name = "gender")
	private WebElement Gender;
	
	@FindBy(xpath = "//*[@class=\"btn btn-fake-input\"]")
	private WebElement Organization;
	
	@FindBy(xpath = "(//*[@class=\"btn btn-blue btn-tiny btn-full\"])[1]")
	private WebElement SelectOrganization;
	
	
	@FindBy(name = "email")
	private WebElement Email;
	
	
	
	@FindBy(name = "password1")
	private WebElement password1;
	
	@FindBy(name = "password2")
	private WebElement password2;
	
	@FindBy(xpath = "//label[@class=\"has--custom-checkbox\"]/input[1]")
	private WebElement checkbxpolicy;
	
	@FindBy(xpath = "//*[contains(text(),' hereby expressly consent')]")
	private WebElement checkbxconsent;
	
	@FindBy(xpath = "(//span[@class=\"tenant-button-text\"])[1]")
	private WebElement SelectTariffbtn;
	
	@FindBy(xpath = "//*[contains(text(),\"PROFESSIONAL CARE\")]")
	private WebElement Selecttarif;
	
	@FindBy(xpath = "//*[@class=\"btn btn-blue btn-big\"]")
	private WebElement Tariffokbtn;
	
	public RegistrationPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void doRegistration(String firstname ,String lastname ,String email , String Password1, String Password2) throws InterruptedException
	{
		GenericLib.clickElement(driver, CreateAccbtn ,"createaccountbutton");
		
		GenericLib.clickElement(driver,  doctorbtn ,"doctoraccountbutton");
		GenericLib.enterText(driver, FirstName, firstname, "firstname TextBox");
		GenericLib.enterText(driver, LastName, lastname, "lastname TextBox");
		GenericLib.clickElement(driver, Gender  ,"gender");
		Select Gender = new Select(driver.findElement(By.name("gender")));
		Gender.selectByIndex(1);
		int randomPIN = (int)(Math.random()*9000)+1000;
		String Email1="autodoc"+randomPIN+"@gmail.com";
		System.out.println(Email1);
		String Email3 = excelLib.getData("Sheet1",1,2,Iconstants.RegistrationPath);
		 try {
	            FileInputStream file = new FileInputStream("C:\\Users\\Admin\\git\\WombaTelemedicine\\womba-telemedicine\\src\\test\\resources\\excel\\Mailtrap.xlsx");

	            XSSFWorkbook workbook = new XSSFWorkbook(file);
	            XSSFSheet sheet = workbook.getSheetAt(0);
	            Cell cell = null;

	            //Update the value of cell
	            cell = sheet.getRow(1).getCell(2);
	            cell.setCellValue(Email1);
	            

	            file.close();

	            FileOutputStream outFile =new FileOutputStream(new File("C:\\Users\\Admin\\git\\WombaTelemedicine\\womba-telemedicine\\src\\test\\resources\\excel\\Mailtrap.xlsx"));
	            workbook.write(outFile);
	            outFile.close();

	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		 try {
	            FileInputStream file1 = new FileInputStream("C:\\Users\\Admin\\git\\WombaTelemedicine\\womba-telemedicine\\src\\test\\resources\\excel\\Login.xlsx");

	            XSSFWorkbook workbook1 = new XSSFWorkbook(file1);
	            XSSFSheet sheet1 = workbook1.getSheetAt(0);
	            Cell cell1 = null;

	            //Update the value of cell
	            cell1 = sheet1.getRow(5).getCell(1);
	            cell1.setCellValue(Email1);
	            file1.close();
	            FileOutputStream outFile1 =new FileOutputStream(new File("C:\\Users\\Admin\\git\\WombaTelemedicine\\womba-telemedicine\\src\\test\\resources\\excel\\Login.xlsx"));
	            workbook1.write(outFile1);
	            outFile1.close();
 
		 }
	 catch (FileNotFoundException e1) {
        e1.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }
		GenericLib.clickElement(driver, Organization  ,"Organization textbox");
		GenericLib.clickElement(driver,  SelectOrganization,"Organization textbox");
		GenericLib.enterText(driver, Email, Email1, "email TextBox");
		GenericLib.enterText(driver, password1, Password1, "password1 TextBox");
		GenericLib.enterText(driver, password2, Password2, "passwor2 TextBox");
		Thread.sleep(10000);
		Actions ac = new Actions(driver);
		WebElement checkbox1 = driver.findElement(By.xpath("//span[text()=\"Ich akzeptiere den \"]"));
		ac.moveToElement(checkbox1).click().build().perform();
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(3000);
		WebElement checkbox2 = driver.findElement(By.xpath("//*[contains(text(),\"Ich willige hiermit ausdr�cklich ein\")]"));
		ac.moveToElement(checkbox2).click().build().perform();
	
		
	
		GenericLib.clickElement(driver,  SelectTariffbtn ,"SelectTariffbtn");
		Thread.sleep(3000);
		WebElement selecttariff = driver.findElement(By.xpath("//*[contains(text(),\"PROFESSIONAL CARE\")]"));
		ac.moveToElement(selecttariff).click().build().perform();
		GenericLib.clickElement(driver, Tariffokbtn ,"tariff btn");
		String SuccessMessage="Ihr Konto wurde erfolgreich angelegt. Bitte pr�fen Sie Ihre Email und best�tigen Sie die Anlage Ihres Kontos.";
		
	    String AlertSuccess=driver.findElement(By.xpath("//div[@class=\"alert alert-success\"]")).getText();
	
	    Assert.assertEquals(SuccessMessage, AlertSuccess);
	}
}
	

