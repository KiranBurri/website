package com.dunn.telemedicine.pages;

 

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

 

import com.dunn.telemedicine.lib.GenericLib;

 

public class CancelAppointmentPatient {
WebDriver driver;
    
    int i;
    int i1;

 

    @FindBy(xpath = "//i[@class='fa fa-gear fa-lg']")
    private WebElement toggleDropdown;
    
    @FindBy(xpath = "(//li/a)[5]")
    private WebElement cancel;
    
    @FindBy(xpath = "(//li/a)[6]")
    private WebElement Doctorcancel;
    
    @FindBy(xpath = "//button[contains(text(),'Ja, Termin absagen')]")
    private WebElement YesCancel;
    
    @FindBy(xpath = "//button[contains(text(),'Ja, Termin absagen')]")
    private WebElement DoctorYesCancel;
    
    @FindBy(xpath = "//div[@class='navbar-logo']")
    private WebElement Wombalogo;
    
    
    public CancelAppointmentPatient(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }
    
    public void cancelApp() throws InterruptedException {
        Thread.sleep(2000);
        String text2=driver.findElement(By.xpath("//*[@class=\"paging-info\"]")).getText();
        
        System.out.println("Appointment details before cancelling the appointment : "+text2);
        String segments3[] = text2.split("f");
        
         String document3 = segments3[segments3.length - 1];
         System.out.println(document3);
         int iend1 = document3.indexOf("E"); 

 

         String subString1;
         if (iend1 != -1) 
         {
             subString1= document3.substring(1 , iend1-1);
             System.out.println(subString1);
             i=Integer.parseInt(subString1);  
             }
        GenericLib.handleAction(driver, toggleDropdown, "toggleDropdown Button");
        GenericLib.handleAction(driver, cancel, "Cancel Button ");
        GenericLib.handleAction(driver, YesCancel, "Yes Cancel Button ");
        
        Thread.sleep(5000);
         String text1=    driver.findElement(By.xpath("//*[@class=\"paging-info\"]")).getText();
        
        System.out.println("Appointment details after cancelling the appointment : "+text1);
        String segments[] = text1.split("f");
    
        String document = segments[segments.length - 1];
       // System.out.println(document);
        int iend = document.indexOf("E"); 

 

        String subString;
        if (iend != -1) 
        {
            subString= document.substring(1 , iend-1);
            //System.out.println(subString);
            i1=Integer.parseInt(subString); 
            if(i1<i)
            {
                System.out.println("Script success");   
                }
            else
            {
                System.out.println("Script failed");   
            }
        }
    }
    
    public void cancelAppDoc() throws InterruptedException {
        Thread.sleep(2000);
        String text2=    driver.findElement(By.xpath("//*[@class=\"paging-info\"]")).getText();
       
            System.out.println(text2);
            String segments3[] = text2.split("f");
        
            String document3 = segments3[segments3.length - 1];
            System.out.println(document3);
            int iend1 = document3.indexOf("E"); //this finds the first occurrence of "." 

 

            String subString1;
            if (iend1 != -1) 
                {
             subString1= document3.substring(1 , iend1-1);
             System.out.println(subString1);
             i=Integer.parseInt(subString1);  
             }
        GenericLib.handleAction(driver, Wombalogo, "Womba Logo");
        GenericLib.handleAction(driver, toggleDropdown, "toggleDropdown Button");
        GenericLib.handleAction(driver, Doctorcancel, "Cancel Button ");
        GenericLib.handleAction(driver, DoctorYesCancel, "Cancel Button ");
        
        Thread.sleep(5000);
         String text1=    driver.findElement(By.xpath("//*[@class='paging-info']")).getText();
       
       System.out.println(text1);
       String segments[] = text1.split("f");
   
       String document = segments[segments.length - 1];
       System.out.println(document);
       int iend = document.indexOf("E"); 

 

       String subString;
       if (iend != -1) 
       {
           subString= document.substring(1 , iend-1);
           System.out.println(subString);
           i1=Integer.parseInt(subString); 
           if(i1<i)
           {
               System.out.println("Script success");   
               }
           else
           {
               System.out.println("Script failed");   
           }
       }

 

        
    }
}