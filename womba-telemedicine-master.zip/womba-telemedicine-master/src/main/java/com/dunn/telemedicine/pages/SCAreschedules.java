package com.dunn.telemedicine.pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.dunn.telemedicine.lib.GenericLib;

public class SCAreschedules {
WebDriver driver;
    
    int i;
    int i1;
    


    @FindBy(xpath="//*[text()=\"Vorname\"]")
    private WebElement vorname;
    
    @FindBy(xpath = "//span[@class='ladda-label']")
    private WebElement select ;
    
    @FindBy(xpath = "(//a[@data-toggle='dropdown'])[1]") //(//*[contains(@class, 'dropdown-toggle cog-icon')])[1]  //(//*[contains(@class, 'fa fa-gear fa-lg')])[1]
    private WebElement Reshedulebtn;
    
    @FindBy(xpath = "//a[contains(text(),'Neuterminierung')]")
    private WebElement Reshedulebtndropdown;
    
    @FindBy(xpath = "(//input[@placeholder='TT/MM/JJJJ' and @class='datetime-picker'])[4]")
	private WebElement AptDate;

    @FindBy(xpath = "(//div[@id='timeslotList'])[2]/div/button[1]")
    private WebElement time;
	
	@FindBy(xpath = "(//button[@class='btn btn-blue action-button full' and @type='button'])[1]")
	private WebElement ScheduleAppointment;
	
	@FindBy(xpath = "//button[contains(text(),' CONFIRM ')]")
	private WebElement ConfirmAppointment;
	
	@FindBy(xpath = "//button[contains(text(),'Best�tigen')]")
	private WebElement GermanConfirmAppointment;

	@FindBy(xpath = "//i[@class='fa fa-angle-right']")
	private WebElement datefilternext;
	
	@FindBy(xpath = "")
	private WebElement datefilterprevious;
    
    public SCAreschedules(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
          }
  

 

    public void SCAResheduleappointment() throws InterruptedException {
    	Thread.sleep(2000);
		String text2=driver.findElement(By.xpath("//*[@class=\"paging-info\"]")).getText();
        System.out.println(text2);
    	GenericLib.handleAction(driver, Reshedulebtn, "Reshedule Button");
    	Thread.sleep(5000);
    	GenericLib.handleAction(driver, Reshedulebtndropdown, "Reshedule Button");
    	Thread.sleep(5000);
    	
    	AptDate.clear();
    	Thread.sleep(4000);
    	AptDate.clear();
    	Thread.sleep(4000);
    	SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        String newDate = formatter.format(cal.getTime());
 		
         GenericLib.enterText(driver, AptDate,newDate , "New aptn date Text Box");
         System.out.println("Rechedule date details : "+newDate);
         Thread.sleep(5000);
         GenericLib.clickElement(driver, vorname, "voranmr click");
         Thread.sleep(10000);
         GenericLib.handleAction(driver,time, "time button");
         Thread.sleep(6000);
         JavascriptExecutor js = (JavascriptExecutor) driver;
         js.executeScript("window.scrollBy(0,100)"); 
         Thread.sleep(5000);
         GenericLib.clickElement(driver, ScheduleAppointment, "ScheduleAppointment Button");
         try {
             GenericLib.handleAction(driver, GermanConfirmAppointment, "Confirm Appointment Button");
         	} 
         		catch (Exception e) {
             GenericLib.handleAction(driver, ConfirmAppointment, "Confirm Appointment Button");    
            }
       
         System.out.println("After Scheduling the appointment");
		 String text1=driver.findElement(By.xpath("//*[@class=\"paging-info\"]")).getText();
         
         System.out.println(text1);
         String segments[] = text1.split("f");
         
         String document = segments[segments.length - 1];
         System.out.println(document);
         int iend = document.indexOf("E"); 

         String subString;
         if (iend != -1) 
         {
        	 subString= document.substring(1 , iend-1);
        	 System.out.println(subString);
        	 i1=Integer.parseInt(subString); 
        	 if(i1<i)
        	 {
        		 System.out.println("Script success");   
        	 }
        	 else
        	 {
        		 System.out.println("");   
        	 }
         }

    }
    }

 



