package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class ScAgentVerifyPatient {

	WebDriver driver;
	@FindBy(xpath = "//a[@href=\"#/service-center/verify-patient\"]")
	private WebElement verifySEction;

	@FindBy(id = "firstNameFilter")
	private WebElement Firstname;
	
	@FindBy(xpath = "//*[text()=\"Suche\"]")
	private WebElement SerachBtn;
	
	@FindBy(xpath = "//*[text()=\" Verifizieren \"]")
	private WebElement Verifybtn;
	public ScAgentVerifyPatient(WebDriver driver) {
	    this.driver=driver;
	    PageFactory.initElements(driver, this);
	    }

	public void DoVerification(String name) throws InterruptedException
	
	{
		GenericLib.handleAction(driver,verifySEction , "Verify section");	
		Thread.sleep(5000);
		GenericLib.enterText(driver,Firstname, name, "bsnr no");
		 GenericLib.clickElement(driver,SerachBtn , "Search patient");
		 Thread.sleep(7000);
		 driver.findElement(By.xpath("(//*[text()='"+name+"'])[1]")).click();
		 Thread.sleep(4000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,700)");
		Thread.sleep(3000);
		 GenericLib.clickElement(driver,Verifybtn , "Verify patient");
		 Thread.sleep(3000);
	     String ActualText=driver.findElement(By.xpath("//div[@role='alertdialog' and @aria-live='polite']")).getText(); 
		 
		
		 String ExpectedText="Patient erfolgreich verifiziert.";
		 Assert.assertEquals(ActualText,ExpectedText);
		 
		 
		 
		 
		
	}
	
	
	


}
