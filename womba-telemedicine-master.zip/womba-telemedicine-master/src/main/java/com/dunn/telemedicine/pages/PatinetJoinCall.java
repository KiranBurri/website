package com.dunn.telemedicine.pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.dunn.telemedicine.lib.GenericLib;

public class PatinetJoinCall
{

		WebDriver driver;
		
		@FindBy(xpath = "(//div[text()= \" 123 123 \" ])[1]//following::datatable-body-cell[2]")
	    private WebElement appointmentbtn;
		
		
		

	    public PatinetJoinCall(WebDriver driver) {
	        this.driver=driver;
	        PageFactory.initElements(driver, this);
	        }
	public void joinCall() throws InterruptedException
	{
		Thread.sleep(4000);
	JavascriptExecutor js = (JavascriptExecutor) driver;  
	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", appointmentbtn);
	
		GenericLib.clickElement(driver, appointmentbtn, "voranmr click");	
		
	}
	
	
	
	
}
