package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class Insurance {
WebDriver driver;
	
	@FindBy(id = "navbarDropdownMenuLink")
	private WebElement Dropdown;
	
	@FindBy(xpath = "//a[@id='profile']")
	private WebElement Profile;
	
	@FindBy(xpath = "(//li/a[@class='nav-link'])[2]")   //  (//li[@class='nav-item'])[3]
	private WebElement Insurance;
	
	@FindBy(xpath = "//input[@type='search']")
	private WebElement InsuranceProvider;
	
	@FindBy(xpath = "(//input[@type='text'])[1]")
	private WebElement PolicyNumber;
	
	@FindBy(xpath = "(//input[@type='text'])[2]")
	private WebElement PatientNumber;
	
	@FindBy(xpath = "(//button[@class='btn btn-smallAdd ng-star-inserted'])[1]")
	private WebElement Fronttakephoto;
	
	@FindBy(xpath = "(//button[@class='btn btn-smallAdd ng-star-inserted'])[2]")
	private WebElement Backtakephoto;
	
	@FindBy(xpath = "(//i[@class='fa fa-file-image-o'])[1]")
	private WebElement chooseFile1;
	
	@FindBy(xpath = "(//button[@class='btn btn-blue'])[1]")
	private WebElement chooseFile2;
	
	@FindBy(xpath = "(//button[@class='btn btn-blue'])[2]")
    private WebElement Continue;
	
	@FindBy(xpath = "(//button[@type='submit'])[2]")
    private WebElement Submit;
	
	@FindBy(xpath = "(//button[@class='btn btn-blue'])[4]")
    private WebElement Continue1;
	
	@FindBy(xpath = "(//button[@type='submit'])[3]")
    private WebElement Submit1;
	
	@FindBy(xpath  = "//button[contains(text(),'Speichern')]")
	private WebElement save;
	
	@FindBy(xpath = "//div[@role='alertdialog']")
	private WebElement alertmessage;
	
	public Insurance(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void profile() {
		GenericLib.handleAction(driver, Dropdown, "DropDown Button");
		GenericLib.handleAction(driver, Profile, "Profile Button");
		}
	
	public void insurance() throws InterruptedException {
		GenericLib.handleAction(driver, Insurance, "Insurance Button");
		Thread.sleep(5000);
		InsuranceProvider.click();
		InsuranceProvider.clear();
		Thread.sleep(5000);
		GenericLib.enterText(driver, InsuranceProvider, "AOK - Die Gesundheitskasse f�r Niedersachsenk ", "InsuranceProvider box");
		Thread.sleep(5000);
		PolicyNumber.clear();
		Thread.sleep(5000);
		GenericLib.enterText(driver, PolicyNumber, "A234567890", "PolicyNumber box");
		Thread.sleep(5000);
		PatientNumber.clear();
		Thread.sleep(5000);
		GenericLib.enterText(driver, PatientNumber, "888888888", "PatientNumber box");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, Fronttakephoto, "Fronttakephoto Button");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, chooseFile1, "chooseFile1 Button");
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//input[@type='file'])[2]")).sendKeys("C:\\Users\\Admin\\Pictures\\Saved Pictures\\icard.jpg");
		Thread.sleep(5000);
		GenericLib.clickElement(driver, Continue, "Continue Button");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, Submit, "Submit Button");
		GenericLib.handleAction(driver, Backtakephoto, "Backtakephoto Button");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, chooseFile1, "chooseFile1 Button");
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//input[@type='file'])[2]")).sendKeys("C:\\Users\\Admin\\Pictures\\Saved Pictures\\icard1.jpg");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, Continue1, "Continue1 Button");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, Submit1, "Submit1 Button");
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,200)");
		GenericLib.clickElement(driver, save, "Save Button");
		Thread.sleep(5000);
		System.out.println(alertmessage.getText());
		String ExpectedText="Ihr Profil wurde aktualisiert.";
	    String ActualText=     driver.findElement(By.xpath("//div[@role='alertdialog']")).getText();
	    System.out.println(alertmessage.getText());
	    Assert.assertEquals(ActualText,ExpectedText);
	}
}
