package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.dunn.telemedicine.lib.GenericLib;

public class SCAsearchDoctorbyfieldsandselects {
	WebDriver driver;
	
	@FindBy(id = "firstNameFilter")
	private WebElement fname ;
	
	@FindBy(id = "lastNameFilter")
	private WebElement lname ;
	
	@FindBy(id = "organizationFilter")
	private WebElement Organization ;
	
	@FindBy(id = "cityFilter")
	private WebElement City ;
	
	@FindBy(id = "specializationFilter")
	private WebElement Specialization ;
	
	@FindBy(xpath = "//button[@type='submit']")
	private WebElement Search;
	
	@FindBy(xpath = "//span[@class='ladda-label']")
	private WebElement select ;
	
	public SCAsearchDoctorbyfieldsandselects(WebDriver driver) {
    this.driver = driver; 
    PageFactory.initElements(driver, this);
	}

	public void SC_searchbyfname() throws InterruptedException {
		driver.findElement(By.xpath("//i[@class='fa fa-users']")).click();
		GenericLib.enterText(driver, fname, "Doctor", "Firstname Filter Box");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, Search, "Search Button");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, select, "Select Button");
	}
	
	public void SC_searchbylname() throws InterruptedException {
		GenericLib.enterText(driver, lname, "Automation1", "Last name Filter Box");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, Search, "Search Button");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, select, "Select Button");
	}
	
	public void SC_searchbyOrg() throws InterruptedException {
		GenericLib.enterText(driver, Organization, "Unknown Location", "Organization Filter Box");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, Search, "Search Button");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, select, "Select Button");
	}
	
	public void SC_searchbyCity() throws InterruptedException {
		GenericLib.enterText(driver, City, "", "City Filter Box");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, Search, "Search Button");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, select, "Select Button");
	}
	
	public void SC_searchbySpecilization() throws InterruptedException {
		GenericLib.enterText(driver, Specialization, "Allergology", "Specialization Filter Box");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, Search, "Search Button");
		Thread.sleep(5000);
		GenericLib.handleAction(driver, select, "Select Button");
	}
	
}

