package com.dunn.telemedicine.pages;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.dunn.telemedicine.lib.GenericLib;

public class SCAschedulesappointment {
	WebDriver driver;
	
	int i;
    int i1;
    
	@FindBy(xpath = "//span[@class='ladda-label']")
	private WebElement select ;
	
	@FindBy(xpath = "(//button[@type='button'])[1]")
	private WebElement newAptButton ;
	
	@FindBy(id = "firstName")
	private WebElement fname ;
	
	@FindBy(id = "lastName")
	private WebElement lname ;
	
	@FindBy(id = "email")
	private WebElement Email ;
	
	@FindBy(xpath = "//input[@class='datetime-picker' and @name='dob' and @placeholder='TT/MM/JJJJ']")
	private WebElement Dob;
	
	@FindBy(xpath = "//input[@class='datetime-picker' and @name='appointmentDate']")
	private WebElement AptDate;

	@FindBy(xpath = "(//button[@type='button'])[8]")
	private WebElement time;
	
	@FindBy(xpath = "//button[@type='submit']")
	private WebElement ScheduleAppointment;
	
	@FindBy(xpath = "//button[contains(text(),' CONFIRM ')]")
	private WebElement ConfirmAppointment;
	
@FindBy(xpath = "//button[contains(text(),'Best�tigen')]")
	private WebElement GermanConfirmAppointment;
	
	public SCAschedulesappointment(WebDriver driver) {
    this.driver = driver; 
    PageFactory.initElements(driver, this);
	}

	public void newAppointment() throws InterruptedException {
		
		Thread.sleep(2000);
		String text2=driver.findElement(By.xpath("//*[@class=\"paging-info\"]")).getText();
        System.out.println("Before Scheduling the appointment");
        System.out.println(text2);
        String segments3[] = text2.split("f");
        
    // Grab the last segment
         String document3 = segments3[segments3.length - 1];
         //System.out.println(document3);
         int iend1 = document3.indexOf("E"); //this finds the first occurrence of "." 
  //in string thus giving you the index of where it is in the string



  // Now iend can be -1, if lets say the string had no "." at all in it i.e. no "." is found. 
  //So check and account for it.



  String subString1;
  if (iend1 != -1) 
  {
      subString1= document3.substring(1 , iend1-1);
    //  System.out.println(subString1);
       i=Integer.parseInt(subString1);  
  }
  		Thread.sleep(5000);
		GenericLib.handleAction(driver, newAptButton, "New Apt Button Button");
		Thread.sleep(5000);
		GenericLib.enterText(driver, fname, "Test", "fname Box");
		Thread.sleep(5000);
		GenericLib.enterText(driver, lname, "Patient2020", "lname Box");
		Thread.sleep(5000);
		GenericLib.enterText(driver, Email, "testpatient2020@gmail.com", "Email Box");
		Dob.click();
		Thread.sleep(5000);
		GenericLib.enterText(driver, Dob, "01/02/1996", "DOB Text Box");
		GenericLib.clickElement(driver, fname, "");
		Thread.sleep(5000);
		AptDate.clear();
		Thread.sleep(5000);
		GenericLib.enterText(driver, AptDate,"*" , "Aptdate Text Box");
		Thread.sleep(5000);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    Date date = new Date();  
	    System.out.println(formatter.format(date)); 
        String startdate=formatter.format(date);
		GenericLib.enterText(driver, AptDate, "date", "Apt Text Box");
		Thread.sleep(3000);
		GenericLib.clickElement(driver, fname, "");
		Thread.sleep(3000);
		GenericLib.clickElement(driver, time, "time button");
		GenericLib.clickElement(driver, ScheduleAppointment, "ScheduleAppointment Button");
		try {
			GenericLib.handleAction(driver, GermanConfirmAppointment, "Confirm Appointment Button");
		} catch (Exception e) {
			GenericLib.handleAction(driver, ConfirmAppointment, "Confirm Appointment Button");		}
		Thread.sleep(5000);
		System.out.println("After Scheduling the appointment");
		 String text1=driver.findElement(By.xpath("//*[@class=\"paging-info\"]")).getText();
         
         System.out.println(text1);
         String segments[] = text1.split("f");
         
         String document = segments[segments.length - 1];
        // System.out.println(document);
         int iend = document.indexOf("E"); 

         String subString;
         if (iend != -1) 
         {
        	 subString= document.substring(1 , iend-1);
        	// System.out.println(subString);
        	 i1=Integer.parseInt(subString); 
        	 if(i1>i)
        	 {
        		 System.out.println("Script success");   
        	 }
        	 else
        	 {
        		 System.out.println("Script failed");   
        	 }
         }
	}
}
