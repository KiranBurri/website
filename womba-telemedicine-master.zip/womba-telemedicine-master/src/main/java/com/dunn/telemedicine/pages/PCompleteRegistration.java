package com.dunn.telemedicine.pages;

 

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

 

import com.dunn.telemedicine.lib.GenericLib;

 

public class PCompleteRegistration {
    WebDriver driver;
    
    //PERSONAL STEP 1 of 3
    @FindBy(name = "timezone")
    private WebElement Timezone;
    
    @FindBy(xpath = "//input[@name='dob' and @placeholder='DD.MM.YYYY']")
    private WebElement dob;

 

    @FindBy(xpath = "//button[contains(text(),'N�chste Seite')]")
    private WebElement Next;
    
    @FindBy(xpath = "//div[@role='alertdialog']")
    private WebElement alertmessage;
    
    //ADDRESS STEP 2 of 3
    
    @FindBy(xpath = "(//li[@class='nav-item'])[2]")
    private WebElement Address;
    
    @FindBy(name = "address1")
    private WebElement Address1;
    
    @FindBy(name = "zip")
    private WebElement ZIP;
    
    @FindBy(name = "city")
    private WebElement CITY;
    
    @FindBy(name = "mobilePhoneCountryCode")
    private WebElement MbCountryCode;
    
    @FindBy(name = "mobilePhone")
    private WebElement MBNumber;
    
    //INSURANCE Step 3 of 3 
    
    @FindBy(xpath = "(//input[@type='search'])[1]")
    private WebElement InsuranceProvider;
    
    @FindBy(xpath = "(//input[@type='search'])[2]")
    private WebElement InsuranceProvidera;
    
    @FindBy(xpath = "(//input[@type='text'])[1]")
    private WebElement PolicyNumber;
    
    @FindBy(xpath = "(//input[@type='text'])[2]")
    private WebElement PatientNumber;
    
    @FindBy(xpath = "(//button[contains(text(),'Fotografieren')])[1]")
    private WebElement Fronttakephoto;
    
    @FindBy(xpath = "(//button[contains(text(),'Fotografieren')])[1]")
    private WebElement Backtakephoto;
    
    @FindBy(xpath = "(//i[@class='fa fa-file-image-o'])[1]")
    private WebElement chooseFile1;
    
    @FindBy(xpath = "(//i[@class='fa fa-file-image-o'])[2]")
    private WebElement chooseFile2;
    
    @FindBy(xpath = "(//button[@class='btn btn-blue'])[2]")
    private WebElement Continue;
    
    @FindBy(xpath = "(//button[@type='submit'])[2]")
    private WebElement Submit;
    
    @FindBy(xpath = "(//button[@class='btn btn-blue'])[2]")
    private WebElement Continue1;
    
    @FindBy(xpath = "(//button[@type='submit'])[2]")
    private WebElement Submit1;
    
    @FindBy(xpath = "//button[contains(text(),'Registrierung best�tigen')]")
    private WebElement completeregistration;
    

 

    public PCompleteRegistration(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }
    
    public void step1() throws InterruptedException {
        Thread.sleep(5000);
        GenericLib.enterText(driver, dob, "01.01.1996", "DOB field");
        Select sc = new Select(Timezone);
        sc.selectByValue("Europe/Berlin");
        Thread.sleep(5000);
        GenericLib.handleAction(driver, Next, "Next Button");
        Thread.sleep(5000);
        System.out.println("Step 1 Message :" +alertmessage.getText());
    }
    
    public void step2() throws InterruptedException {
        GenericLib.enterText(driver, Address1, "4th Street , 3rd Cross ", "Address1 box");
        GenericLib.enterText(driver, ZIP, "570024", "ZIP box");
        GenericLib.enterText(driver, CITY, "MYSORE", "CITY box");
        Select sc = new Select(MbCountryCode);
        sc.selectByVisibleText("Indien (+91)");
        GenericLib.enterText(driver, MBNumber, "8792734161", "MBNumber box");
        Thread.sleep(5000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,100)");
        Thread.sleep(5000);
        GenericLib.clickElement(driver, Next, "Next Button");
        Thread.sleep(5000);
        System.out.println("Step 2 Message :" +alertmessage.getText());
    }
    
    public void step3 () throws InterruptedException {
        InsuranceProvider.clear();
            GenericLib.enterText(driver, InsuranceProvider, "AOK - Die Gesundheitskasse f�r Niedersachsen", "InsuranceProvider box");
            PolicyNumber.clear();
            GenericLib.enterText(driver, PolicyNumber, "A234567890", "PolicyNumber box");
            PatientNumber.clear();
            GenericLib.enterText(driver, PatientNumber, "888888888", "PatientNumber box");
            GenericLib.handleAction(driver, Fronttakephoto, "Fronttakephoto Button");
            Thread.sleep(5000);
            GenericLib.handleAction(driver, chooseFile1, "chooseFile1 Button");
            Thread.sleep(5000);
            driver.findElement(By.xpath("(//input[@type='file'])[2]")).sendKeys("C:\\Users\\Admin\\Pictures\\Saved Pictures\\icard.jpg");
            Thread.sleep(5000);
            GenericLib.clickElement(driver, Continue, "Continue Button");
            Thread.sleep(5000);
            GenericLib.enterText(driver, InsuranceProvidera, "AOK - Die Gesundheitskasse f�r Niedersachsen", "InsuranceProvider box");
            Thread.sleep(5000);
//            InsuranceProvider2.clear();
//            GenericLib.enterText(driver, InsuranceProvider2, "AOK - Die Gesundheitskasse f�r Niedersachsenk", "InsuranceProvider box");
            GenericLib.handleAction(driver, Submit, "Submit Button");
            GenericLib.handleAction(driver, Backtakephoto, "Backtakephoto Button");
            Thread.sleep(5000);
            GenericLib.handleAction(driver, chooseFile2, "chooseFile2 Button");
            Thread.sleep(5000);
            driver.findElement(By.xpath("(//input[@type='file'])[2]")).sendKeys("C:\\Users\\Admin\\Pictures\\Saved Pictures\\icard1.jpg");
            Thread.sleep(5000);
            GenericLib.handleAction(driver, Continue1, "Continue1 Button");
            Thread.sleep(5000);
            GenericLib.handleAction(driver, Submit1, "Submit1 Button");
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy(0,70)");
            Thread.sleep(5000);
            GenericLib.clickElement(driver, completeregistration, "Confirm Registration Button");
            Thread.sleep(5000);
            System.out.println("Step 3 Message :" +alertmessage.getText());
        }
    }
