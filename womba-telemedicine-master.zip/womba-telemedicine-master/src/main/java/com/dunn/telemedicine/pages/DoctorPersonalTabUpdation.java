package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class DoctorPersonalTabUpdation {
WebDriver driver;
@FindBy(id = "navbarDropdownMenuLink")
private WebElement Dropdown;

@FindBy(xpath = "//a[@id='profile']")
private WebElement Profile;
@FindBy(name = "firstName")
private WebElement FirstNametext;

@FindBy(name = "lastName")
private WebElement LastNametext;



@FindBy(xpath = "//button[@class=\"btn btn-smallAdd\"]")
private WebElement Addlanguagebtn ;
	
@FindBy(xpath = "//button[@class=\"btn btn-blue save pull-right\"]")
private WebElement Savebtn ;

@FindBy(xpath = "//div[@role='alertdialog']")
private WebElement alertmessage;

	public DoctorPersonalTabUpdation(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
        
        
	}
 public void Docpersonaltabupdate() throws InterruptedException
  {JavascriptExecutor js = (JavascriptExecutor) driver;
	 GenericLib.clickElement(driver,Dropdown, "profiledropdown");
	 GenericLib.clickElement(driver,Profile, "profileSelect");
	 Thread.sleep(4000);
	 
	 driver.findElement(By.name("firstName")).clear();
	 Thread.sleep(3000);
	 driver.findElement(By.name("firstName")).sendKeys("David");
	 Thread.sleep(3000);
	 driver.findElement(By.name("lastName")).clear();
	 Thread.sleep(3000);
	 driver.findElement(By.name("lastName")).sendKeys("Ronald");
	 js.executeScript("window.scrollBy(0,200)");
	 Thread.sleep(3000);
	 Select Location= new Select(driver.findElement(By.name("timezone")));
	 Location.selectByVisibleText("Europe/Berlin, Central European Time");
	 Select Language= new Select(driver.findElement(By.xpath("//*[@class=\"form-control multipleSelect ng-untouched ng-pristine ng-valid\"]")));
	 Language.selectByVisibleText("English");
	 GenericLib.clickElement(driver,Addlanguagebtn, "Addlanguagebtn");
	 Select Language2= new Select(driver.findElement(By.xpath("//*[@class=\"form-control multipleSelect ng-untouched ng-pristine ng-valid\"]")));
	 Language2.selectByVisibleText("Deutsch");
	 Thread.sleep(2000);
	 js.executeScript("window.scrollBy(0,200)");
	 GenericLib.clickElement(driver,Savebtn, "Savebtn");
	 
	 String ExpectedText="Ihr Profil wurde aktualisiert.";
	 WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='alertdialog']")));
     String ActualText=     driver.findElement(By.xpath("//div[@role='alertdialog']")).getText();
          System.out.println(alertmessage.getText());
          
          Assert.assertEquals(ExpectedText, ActualText);
          Thread.sleep(4000);
	 
  }
 
}
