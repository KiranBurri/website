package com.dunn.telemedicine.lib;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class excelLib {
	public static String getData(String sheet,int row,int cell,String filepath) 
	{
		String data="";
		
		try {
			FileInputStream fin = new FileInputStream(filepath);
			Workbook wb = WorkbookFactory.create(fin);
	Cell c = wb.getSheet(sheet).getRow(row).getCell(cell);		
	data = c.getStringCellValue();

			} catch (Exception e) {
			

	

			}
		return data;
		
	}
}
