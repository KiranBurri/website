package com.dunn.telemedicine.init;

public interface Iconstants {
	String projDir = System.getProperty("user.dir");
	String screenshotsPath = projDir+"\\screenshots\\ss";
	String DataexcelPath = projDir+"\\src\\test\\resources\\excel\\Login.xlsx";
	String propData = projDir+"\\src\\main\\resources\\properties\\data.properties";
	String RegistrationPath = projDir+"\\src\\test\\resources\\excel\\Registrationdetails.xlsx";
	String Expectedoutput = projDir+"\\src\\test\\resources\\excel\\ExpectedOutput.xlsx";

    String ExcelopenMrs=projDir+"\\src\\test\\resources\\excel\\OpenMrsCredentials.xlsx";
    String ScAgentPath = projDir+"\\src\\test\\resources\\excel\\ScAgentVerifyPat.xlsx";
    String DataexcelPath1 = projDir+"\\src\\test\\resources\\excel\\mailtrap.xlsx";

}
