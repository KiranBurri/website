package com.dunn.telemedicine.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.dunn.telemedicine.lib.GenericLib;

public class CompleteRegistrationDoctor {
	
	WebDriver driver;
    @FindBy(xpath = "//*[@type=\"submit\"]")
    private WebElement submit1;
    
    @FindBy(name = "address1")
    private WebElement Address1;
    
    @FindBy(name = "zip")
    private WebElement zip;
    
    
    @FindBy(name = "city")
    private WebElement city;
  //button[@type='submit']
   
    
    @FindBy(name="mobilePhone")
    private WebElement MobileNo;
    
    @FindBy(xpath = "//button[@type='submit']")
    private WebElement submit2;
    
  
    		
    @FindBy(name="physicianCertificationNumber")
    private WebElement Certificate;
    
    @FindBy(name="bsnrNumber")
    private WebElement Bsnr;
    
    @FindBy(xpath = "//*[@type=\"submit\"]")
    private WebElement submit3;
    
    
    public CompleteRegistrationDoctor(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
    
  public void  DoCompleteRegistration(String Address,String City ) throws InterruptedException
  { JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,300)");
	GenericLib.clickElement(driver, submit1, "submit btn page1"); 
	Thread.sleep(2000);
	js.executeScript("window.scrollBy(0,-300)");
	Thread.sleep(3000);
	
	GenericLib.enterText(driver, Address1, Address, "input address");
	Thread.sleep(2000);
	
	driver.findElement(By.name("zip")).sendKeys("9731014207");
	
	Thread.sleep(2000);
	GenericLib.enterText(driver, city, City, "input City");
	Thread.sleep(3000);
	
	js.executeScript("window.scrollBy(0,300)");
	Thread.sleep(2000);
	
	Select CallingCode= new Select(driver.findElement(By.name("mobilePhoneCountryCode")));
	CallingCode.selectByVisibleText("Indien (+91)");
	Thread.sleep(2000);
	driver.findElement(By.name("mobilePhone")).sendKeys("9731014207");
	Thread.sleep(2000);
	GenericLib.clickElement(driver, submit2, "submit btn page2");
	Thread.sleep(5000);
	driver.findElement(By.name("physicianCertificationNumber")).sendKeys("987654321");
	Thread.sleep(3000);
	driver.findElement(By.name("bsnrNumber")).sendKeys("987654321");
	Thread.sleep(3000);
	
	Select Specialization= new Select(driver.findElement(By.xpath("//select[@class=\"form-control multipleSelect ng-untouched ng-pristine ng-invalid\"]")));
	Specialization.selectByIndex(1);
	js.executeScript("window.scrollBy(0,200)");
	GenericLib.clickElement(driver, submit3, "submit btn page3");
	Thread.sleep(5000);
/*	String textExpected="Termine";
    String textActual=	driver.findElement(By.xpath("//*[text()=\" Termine \"]")).getText();
    Assert.assertEquals(textActual, textExpected);*/
	
	
  }

}

